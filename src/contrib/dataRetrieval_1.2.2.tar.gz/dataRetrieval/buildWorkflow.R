# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("dataRetrieval/",reset = TRUE)
setwd("D:/LADData/RCode/dataRetrieval")
document()

# export(formatCheckDate)
# export(checkStartEndDate)
# export(dateFormatCheck)
# export(formatCheckParameterCd)
# export(formatCheckSiteNumber)
build()

check()  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
install()