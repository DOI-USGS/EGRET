# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("dataRetrieval/",reset = TRUE)
document("dataRetrieval")
check("dataRetrieval")  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
build("dataRetrieval")
install("dataRetrieval")