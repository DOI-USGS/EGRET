library("dataRetrieval")

sites <-as.character(read.csv("M:/QW Monitoring Team/GLRI toxics/sites.csv")$staid)
sites <- paste("0",sites,sep="")

pCodes4433 <- as.character(read.csv("M:/QW Monitoring Team/GLRI toxics/pcodes4433.csv")$pcodes.4433)
pCodes4433 <- as.character(sapply(pCodes4433, function(x) padVariable(x, 5)))

pCodes5433 <- as.character(read.csv("M:/QW Monitoring Team/GLRI toxics/pcodes5433.csv")$pcodes.5433)
pCodes5433 <- as.character(sapply(pCodes5433, function(x) padVariable(x, 5)))

pCodes7504 <- as.character(read.csv("M:/QW Monitoring Team/GLRI toxics/pcodes7504.csv")$pcodes.7504)
pCodes7504 <- as.character(sapply(pCodes7504, function(x) padVariable(x, 5)))

summaryData <- list()
for (i in 1:length(sites)){
  
  possibleError <- tryCatch(
    siteSummary <- getDataAvailability(sites[i],interactive=FALSE),
    error=function(e) e
  )

  if(!inherits(possibleError, "error")){
    #REAL WORK
    summaryData[[sites[i]]] <- siteSummary
  } else {
    cat("\n", sites[i], "\n")
  }

}

sink("stationCounts4433.txt")
for (i in 1:length(sites)){
  cat("\n",i,": ",sites[i],"\n")
  siteSum <- summaryData[[sites[i]]]
  siteSummary <- siteSum[which(siteSum$parameter_cd %in% pCodes4433),]
  print(siteSummary)
}
sink()

sink("stationCounts5433.txt")
for (i in 1:length(sites)){
  cat("\n",i,": ",sites[i],"\n")
  siteSum <- summaryData[[sites[i]]]
  siteSummary <- siteSum[which(siteSum$parameter_cd %in% pCodes5433),]
  print(siteSummary)
}
sink()

sink("stationCounts7504.txt")
for (i in 1:length(sites)){
  cat("\n",i,": ",sites[i],"\n")
  siteSum <- summaryData[[sites[i]]]
  siteSummary <- siteSum[which(siteSum$parameter_cd %in% pCodes7504),]
  print(siteSummary)
}
sink()