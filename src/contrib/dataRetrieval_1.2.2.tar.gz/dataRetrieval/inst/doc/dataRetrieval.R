### R code from vignette source 'dataRetrieval.Rnw'

###################################################
### code chunk number 1: openLibrary
###################################################
library(xtable)
options(continue=" ")
# options(width=60)
# options(SweaveHooks=list(fig=function()
#   par(mar=c(4.1,4.1,1.1,4.1),oma=c(0,0,0,0))))


###################################################
### code chunk number 2: tableParameterCodes
###################################################
pCode <- c('00060', '00065', '00010','00045','00400')
shortName <- c("Discharge [cfs]","Gage height [ft]","Temperature [C]", "Precipitation [in]", "pH")

data.df <- data.frame(pCode, shortName, stringsAsFactors=FALSE)

data.table <- xtable(data.df,label="tab:params",
                     caption="Common USGS Parameter Codes")
print(data.table,
      caption.placement="top",include.rownames=FALSE, table.placement="!ht")


###################################################
### code chunk number 3: tableStatCodes
###################################################
StatCode <- c('00001', '00002', '00003','00008')
shortName <- c("Maximum","Minimum","Mean", "Median")

data.df <- data.frame(StatCode, shortName, stringsAsFactors=FALSE)

data.table <- xtable(data.df,label="tab:stat",
                     caption="Commonly found USGS Stat Codes")
print(data.table, 
      caption.placement="top",include.rownames=FALSE, table.placement="!ht")


###################################################
### code chunk number 4: getSite
###################################################
library(dataRetrieval)
# Site ID for Choptank River near Greensboro, MD
siteNumber <- "01491000" 
ChoptankInfo <- getSiteFileData(siteNumber)


###################################################
### code chunk number 5: siteNames
###################################################
ChoptankInfo$station.nm


###################################################
### code chunk number 6: getSiteAvailability
###################################################
# Continuing from the previous example:
ChoptankAvailableData <- getDataAvailability(siteNumber)
head(ChoptankAvailableData)


###################################################
### code chunk number 7: getSiteExtended
###################################################
# Continuing from the previous example:
# This pulls out just the daily data:
ChoptankDailyData <- subset(ChoptankAvailableData,"dv" == service)

# This pulls out the mean:
ChoptankDailyData <- subset(ChoptankDailyData,"00003" == statCd)

#Now, make a call to get all of the parameter information:
pCodeINFO <- getMultipleParameterNames(ChoptankDailyData$parameter_cd)

#Merge the available dataframe with the parameter information dataframe:
ChoptankDailyData <- merge(ChoptankDailyData,pCodeINFO,by="parameter_cd")


###################################################
### code chunk number 8: tablegda
###################################################
tableData <- with(ChoptankDailyData, 
      data.frame(shortName=srsname, 
      Start=as.character(startDate), 
      End=as.character(endDate), 
      Count=as.character(count),
      Units=parameter_units)
      )


data.table <- xtable(tableData,label="tab:gda",
    caption="Daily mean data availabile at the Choptank River")
print(data.table, 
      caption.placement="top",include.rownames=FALSE)


###################################################
### code chunk number 9: getSite
###################################################
# Using defaults:
parameterCd <- "00618" 
parameterINFO <- getParameterInfo(parameterCd)
colnames(parameterINFO)


###################################################
### code chunk number 10: siteNames
###################################################
parameterINFO$parameter_nm


###################################################
### code chunk number 11: getNWISDaily (eval = FALSE)
###################################################
## 
## # Continuing with our Choptank River example
## parameterCd <- "00060"  # Discharge (cfs)
## startDate <- ""  # Will request earliest date
## endDate <- "" # Will request latest date
## 
## discharge <- retrieveNWISData(siteNumber, parameterCd, startDate, endDate)


###################################################
### code chunk number 12: getNWIStemperature
###################################################

parameterCd <- c("00010","00060")  # Temperature and discharge
statCd <- c("00001","00003")  # Mean and maximum
startDate <- "2012-01-01"
endDate <- "2012-06-30"

temperatureAndFlow <- retrieveNWISData(siteNumber, parameterCd, 
        startDate, endDate, StatCd=statCd,interactive=FALSE)



###################################################
### code chunk number 13: getNWIStemperaturePlot
###################################################
colnames <- names(temperatureAndFlow)
with(temperatureAndFlow, plot(
  get(colnames[3]), get(colnames[6]),
  xlab="Date",ylab="Temperature [C]"
  ))
par(new=TRUE)
with(temperatureAndFlow, plot(
  get(colnames[3]), get(colnames[8]),
  col="red",type="l",xaxt="n",yaxt="n",xlab="",ylab="",axes=FALSE
  ))
axis(4,col="red",col.axis="red")
mtext("Discharge [cfs]",side=4,line=3,col="red")
title(paste(ChoptankInfo$station.nm,"2012",sep=" "))


###################################################
### code chunk number 14: fig1
###################################################
colnames <- names(temperatureAndFlow)
with(temperatureAndFlow, plot(
  get(colnames[3]), get(colnames[6]),
  xlab="Date",ylab="Temperature [C]"
  ))
par(new=TRUE)
with(temperatureAndFlow, plot(
  get(colnames[3]), get(colnames[8]),
  col="red",type="l",xaxt="n",yaxt="n",xlab="",ylab="",axes=FALSE
  ))
axis(4,col="red",col.axis="red")
mtext("Discharge [cfs]",side=4,line=3,col="red")
title(paste(ChoptankInfo$station.nm,"2012",sep=" "))


###################################################
### code chunk number 15: getNWISUnit
###################################################

parameterCd <- "00060"  # Discharge (cfs)
startDate <- "2012-05-12" 
# or use (yesterday): startDate <- as.character(Sys.Date()-1)
endDate <- "2012-05-13" 
# or use (today):  endDate <- as.character(Sys.Date())
dischargeToday <- retrieveUnitNWISData(siteNumber, parameterCd, 
        startDate, endDate)


###################################################
### code chunk number 16: dischargeData
###################################################
head(dischargeToday)


###################################################
### code chunk number 17: getNWISUnit
###################################################
colnames <- names(dischargeToday)
with(dischargeToday, plot(
  get(colnames[3]), get(colnames[4]),
  ylab="Discharge [cfs]",xlab=""
  ))
title(ChoptankInfo$station.nm)



###################################################
### code chunk number 18: fig2
###################################################
colnames <- names(dischargeToday)
with(dischargeToday, plot(
  get(colnames[3]), get(colnames[4]),
  ylab="Discharge [cfs]",xlab=""
  ))
title(ChoptankInfo$station.nm)



###################################################
### code chunk number 19: getQW
###################################################
 
# Dissolved Nitrate parameter codes:
parameterCd <- c("00618","71851")
startDate <- "1979-10-11"
endDate <- "2012-12-18"

dissolvedNitrate <- getRawQWData(siteNumber, parameterCd, 
      startDate, endDate)

dissolvedNitrateSimple <- getQWData(siteNumber, parameterCd, 
        startDate, endDate)
names(dissolvedNitrateSimple)


###################################################
### code chunk number 20: getQWtemperaturePlot
###################################################
with(dissolvedNitrateSimple, plot(
  dateTime, value.00618,
  xlab="Date",ylab = paste(parameterINFO$srsname,
      "[",parameterINFO$parameter_units,"]")
  ))
title(ChoptankInfo$station.nm)


###################################################
### code chunk number 21: fig3
###################################################
with(dissolvedNitrateSimple, plot(
  dateTime, value.00618,
  xlab="Date",ylab = paste(parameterINFO$srsname,
      "[",parameterINFO$parameter_units,"]")
  ))
title(ChoptankInfo$station.nm)


###################################################
### code chunk number 22: getQWData
###################################################
specificCond <- getWQPData('WIDNR_WQX-10032762', 
        'Specific conductance', '', '')
head(specificCond)


###################################################
### code chunk number 23: geturl (eval = FALSE)
###################################################
## # Dissolved Nitrate parameter codes:
## pCode <- c("00618","71851")
## startDate <- "1964-06-11"
## endDate <- "2012-12-18"
## url_qw <- constructNWISURL(siteNumber,pCode,startDate,endDate,'qw')
## url_dv <- constructNWISURL(siteNumber,"00060",startDate,endDate,'dv',statCd="00003")
## url_uv <- constructNWISURL(siteNumber,"00060",startDate,endDate,'uv')


###################################################
### code chunk number 24: ThirdExample
###################################################
parameterCd <- "00618"
INFO <-getMetaData(siteNumber,parameterCd, interactive=FALSE)


###################################################
### code chunk number 25: firstExample
###################################################
siteNumber <- "01491000"
startDate <- "2000-01-01"
endDate <- "2013-01-01"
# This call will get NWIS data that is in cfs, and convert it
# to cms since we didn't override the default in the convert argument:
Daily <- getDVData(siteNumber, "00060", startDate, endDate,interactive=FALSE)


###################################################
### code chunk number 26: colNamesDaily
###################################################
ColumnName <- c("Date", "Q", "Julian","Month","Day","DecYear","MonthSeq","Qualifier","i","LogQ","Q7","Q30")
Type <- c("Date", "number", "number","integer","integer","number","integer","string","integer","number","number","number")
Description <- c("Date", "Discharge", "Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Qualifing code", "Index of days from the start of the data frame", "Natural logarithm of Q", "7 day running average of Q", "30 running average of Q")
Units <- c("date", "cms","days", "months","days","years","months", "character","days","numeric","cms","cms")

DF <- data.frame(ColumnName,Type,Description,Units)

data.table <- xtable(DF,
                     caption="Daily dataframe")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL,include.rownames=FALSE)


###################################################
### code chunk number 27: secondExample
###################################################
Sample <-getSampleData(siteNumber,parameterCd,
      startDate, endDate,interactive=FALSE)


###################################################
### code chunk number 28: colNamesQW
###################################################
ColumnName <- c("Date", "ConcLow", "ConcHigh", "Uncen", "ConcAve", "Julian","Month","Day","DecYear","MonthSeq","SinDY","CosDY","Q footnote","LogQ footnote")
Type <- c("Date", "number","number","integer","number", "number","integer","integer","number","integer","number","number","number","number")
Description <- c("Date", "Lower limit of concentration", "Upper limit of concentration", "Uncensored data (1=true, 0=false)", "Average of ConcLow and ConcHigh","Number of days since January 1, 1850", "Month of the year [1-12]", "Day of the year [1-366]", "Decimal year", "Number of months since January 1, 1850", "Sine of DecYear", "Cosine of DecYear", "Discharge", "Natural logarithm of flow")
Units <- c("date","mg/L","mg/L","integer","mg/L","days","months","days","years","months","numeric","numeric","cms", "numeric")

DF <- data.frame(ColumnName,Type,Description,Units)

data.table <- xtable(DF,
                     caption="Sample dataframe")
print(data.table, caption.placement="top",include.rownames=FALSE,table.placement="!ht",
      sanitize.text.function=function(str)gsub("footnote","\\footnotemark[1]",str,fixed=TRUE))


###################################################
### code chunk number 29: exampleComplexQW
###################################################
cdate <- c("2003-02-15","2003-06-30","2004-09-15","2005-01-30","2005-05-30","2005-10-30")
rdp <- c("", "<","<","","","")
dp <- c(0.02,0.01,0.005,NA,NA,NA)
rpp <- c("", "","<","","","")
pp <- c(0.5,0.3,0.2,NA,NA,NA)
rtp <- c("","","","","<","<")
tp <- c(NA,NA,NA,0.43,0.05,0.02)

DF <- data.frame(cdate,rdp,dp,rpp,pp,rtp,tp)

data.table <- xtable(DF,
                     caption="Example data")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL,include.rownames=FALSE)


###################################################
### code chunk number 30: thirdExample
###################################################
getPreLoadedSampleData(DF)



###################################################
### code chunk number 31: openDaily (eval = FALSE)
###################################################
## fileName <- "ChoptankRiverFlow.txt"
## filePath <-  "C:/RData/"
## Daily <- getDailyDataFromFile(filePath,fileName,separator="\t",interactive=FALSE)


###################################################
### code chunk number 32: openSample (eval = FALSE)
###################################################
## fileName <- "ChoptankRiverNitrate.csv"
## filePath <-  "C:/RData/"
## Sample <- getSampleDataFromFile(filePath,fileName,separator=",",interactive=FALSE)


###################################################
### code chunk number 33: mergeExample
###################################################
siteNumber <- "01491000"
parameterCd <- "00631"  # Nitrate
startDate <- "2000-01-01"
endDate <- "2013-01-01"

Daily <- getDVData(siteNumber, "00060", startDate, endDate,interactive=FALSE)
Sample <- getSampleData(siteNumber,parameterCd, startDate, endDate, interactive=FALSE)
Sample <- mergeReport()
head(Sample)


###################################################
### code chunk number 34: egretEx
###################################################
# Continuing Choptank example from the previous sections
library(EGRET)
multiPlotDataOverview()


###################################################
### code chunk number 35: figegretEx
###################################################
# Continuing Choptank example from the previous sections
library(EGRET)
multiPlotDataOverview()


###################################################
### code chunk number 36: helpFunc (eval = FALSE)
###################################################
## ?removeDuplicates


###################################################
### code chunk number 37: rawFunc
###################################################
removeDuplicates


###################################################
### code chunk number 38: installFromCran (eval = FALSE)
###################################################
## install.packages("zoo")
## install.packages("dataRetrieval", repos="http://usgs-r.github.com", type="source")


###################################################
### code chunk number 39: openLibraryTest (eval = FALSE)
###################################################
## library(dataRetrieval)


###################################################
### code chunk number 40: gitInstal (eval = FALSE)
###################################################
## library(devtools)
## install_github("dataRetrieval", "USGS-R")


###################################################
### code chunk number 41: openLibrary (eval = FALSE)
###################################################
## library(dataRetrieval)


###################################################
### code chunk number 42: colNamesQW
###################################################
infoDF <- data.frame(ColumnNames=names(INFO))
data.table <- xtable(infoDF,
                     caption="Column names in the INFO dataframe")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL,include.rownames=FALSE,include.colnames=FALSE)


###################################################
### code chunk number 43: colNamesQW
###################################################
infoDF <- data.frame(ColumnNames=names(dissolvedNitrate[1:40]))
data.table <- xtable(infoDF,
                     caption="Column names in dissolvedNitrate")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL,
      include.rownames=FALSE,include.colnames=FALSE)


###################################################
### code chunk number 44: colNamesQW2
###################################################
infoDF <- data.frame(ColumnNames_Continued=names(dissolvedNitrate[41:62]))
data.table <- xtable(infoDF,
                     caption="Column names in dissolvedNitrate")
print(data.table, caption.placement="top",floating="FALSE",latex.environments=NULL,
      include.rownames=FALSE,include.colnames=FALSE)


###################################################
### code chunk number 45: getSiteApp
###################################################
ChoptankAvailableData <- getDataAvailability(siteNumber)
ChoptankDailyData <- ChoptankAvailableData["dv" == ChoptankAvailableData$service,]
ChoptankDailyData <- ChoptankDailyData["00003" == ChoptankDailyData$statCd,]
pCodeINFO <- getMultipleParameterNames(ChoptankDailyData$parameter_cd, interactive=FALSE)
ChoptankDailyData <- merge(ChoptankDailyData,pCodeINFO,by="parameter_cd")

tableData <- with(ChoptankDailyData, 
      data.frame(
      shortName=srsname, 
      Start=startDate, 
      End=endDate, 
      Count=count,
      Units=parameter_units)
      )


###################################################
### code chunk number 46: saveData (eval = FALSE)
###################################################
## write.table(tableData, file="tableData.tsv",sep="\t",
##             row.names = FALSE,quote=FALSE)


