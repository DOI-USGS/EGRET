#' Confidence Interval package for EGRET
#'
#' \tabular{ll}{
#' Package: \tab dataRetrieval\cr
#' Type: \tab Package\cr
#' Version: \tab 1.0.0\cr
#' Date: \tab 2013-08-09\cr
#' License: \tab Unlimited for this package, dependencies have more restrictive licensing.\cr
#' Copyright: \tab This software is in the public domain because it contains materials
#' that originally came from the United States Geological Survey, an agency of
#' the United States Department of Interior. For more information, see the
#' official USGS copyright policy at
#' http://www.usgs.gov/visual-id/credit_usgs.html#copyright\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' Collection of functions to help retrieve USGS data from either web services or user provided data files.
#'
#' @name CI-package
#' @docType package
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}, Laura De Cicco \email{ldecicco@@usgs.gov}
#' @keywords confidence
NULL

#' Example Daily dataframe
#'
#' Example data representing streamflowfrom the Choptank River at Greensboro, MD,  USGS data
#' as agumented by the modelEstimation process.
#'
#' @name exDaily
#' @docType data
#' @source Data retrieved from NWIS water services (\url{http://waterservices.usgs.gov/}) via the dataRetrieval R package.
#' The USGS site id is 01491000. The period requested was 1979-10-01 to 2011-09-30. 
#' @format Data frame with 11688 rows and 18 columns:
#' \tabular{llll}{
#' ColumnName \tab Type \tab Description \tab Units  \cr
#' Date \tab Date \tab Date \tab date \cr 
#' Q \tab number \tab Discharge in cms \tab cms \cr 
#' Julian \tab number \tab Number of days since January 1, 1850 \tab days \cr 
#' Month \tab integer \tab Month of the year [1-12] \tab months \cr 
#' Day \tab integer \tab Day of the year [1-366] \tab days \cr 
#' DecYear \tab number \tab Decimal year \tab years \cr 
#' MonthSeq \tab integer \tab Number of months since January 1, 1850 \tab months \cr 
#' Qualifier \tab string \tab Qualifing code \tab character \cr 
#' i \tab integer \tab Index of days, starting with 1 \tab days \cr 
#' LogQ \tab number \tab Natural logarithm of Q \tab numeric \cr 
#' Q7 \tab number \tab 7 day running average of Q \tab cms \cr
#' Q30 \tab number \tab 30 running average of Q \tab cms \cr
#' yHat \tab number \tab The WRTDS estimate of the log of concentration \tab numeric \cr 
#' SE \tab number \tab The WRTDS estimate of the standard error of yHat \tab numeric \cr 
#' ConcDay \tab number \tab The WRTDS estimate of concentration \tab mg/L \cr 
#' FluxDay \tab number \tab The WRTDS estimate of flux \tab kg/day \cr 
#' FNConc \tab number \tab Flow normalized estimate of concentration \tab mg/L \cr 
#' FNFlux \tab number \tab Flow Normalized estimate of flux \tab kg/day \cr 
#' }
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water quality streamflow data
#' @examples
#' Daily <- exDaily
#' with(Daily, plot(Date, LogQ, type="l"))
NULL

#' Example Sample dataframe
#'
#' Example data representing Nitrate sample data from the Choptank River at Greensboro, MD,  USGS data
#' as agumented by the modelEstimation process
#'
#' @name exSample
#' @docType data
#' @source Nitrate/nitrite data retrieved from National Water Quality Monitoring Council (NWQMC) Water Quality Portal
#' (\url{http://www.waterqualitydata.us/}), and discharge retrieved from NWIS water services (\url{http://waterservices.usgs.gov/}), both via the dataRetrieval R package.
#' The USGS site id is 01491000. The period requested was 1979-10-01 to 2011-09-30. The parameter was Inorganic nitrogen (nitrate and nitrite), 
#' USGS parameter code 00631.
#' @format Data frame with 606 rows and 17 columns:
#' \tabular{llll}{
#' ColumnName \tab Type \tab Description \tab Units  \cr
#' Date \tab Date \tab Date \tab date \cr 
#' ConcLow \tab number \tab Lower limit of concentration \tab mg/L \cr
#' ConcHigh \tab number \tab Upper limit of concentration \tab mg/L \cr
#' Uncen \tab integer \tab Uncensored data (1=true, 0=false) \tab integer \cr 
#' ConcAve \tab number \tab Average concentration \tab mg/L \cr
#' Julian \tab number \tab Number of days since January 1, 1850 \tab days \cr 
#' Month \tab integer \tab Month of the year [1-12] \tab months \cr 
#' Day \tab integer \tab Day of the year [1-366] \tab days \cr 
#' DecYear \tab number \tab Decimal year \tab years \cr 
#' MonthSeq \tab integer \tab Number of months since January 1, 1850 \tab months \cr 
#' SinDY \tab number \tab Sine of DecYear \tab numeric \cr 
#' CosDY \tab number \tab Cosine of DecYear \tab numeric \cr 
#' Q \tab number \tab Discharge \tab cms \cr 
#' LogQ \tab number \tab Natural logarithm of flow \tab numeric \cr
#' yHat \tab number \tab estimate of the log of concentration \tab numeric \cr 
#' SE \tab number \tab estimate of the standard error of yHat \tab numeric \cr 
#' ConcHat \tab number \tab unbiased estimate of concentration \tab mg/L \cr
#' }
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water quality data
#' @examples
#' Sample <- exSample
#' with(Sample, plot(Date, ConcAve))
NULL

#' Example INFO dataframe
#'
#' Example data representing meta-data from the Choptank River at Greensboro, MD,  USGS data
#' as augmented by the functions setupYears (for WRTDS) and setPA (for flowHistory).
#'
#' @name exINFO
#' @docType data
#' @source Parameter information (Nitrate/nitrite, USGS parameter code 00631) is found from NWISweb (\url{http://nwis.waterdata.usgs.gov/nwis/pmcodes/}), and station
#' information is retrieved from NWIS water services (\url{http://waterservices.usgs.gov/}), both via the dataRetrieval R package.
#' The USGS site id is 01491000. 
#' @format Data frame with 1 row and 56 columns, some of which are described here:
#' \tabular{lll}{
#' ColumnName \tab Type \tab Description \cr
#' shortName \tab string \tab Name of site, suitable for use in graphical headings \cr 
#' staAbbrev \tab string \tab Abbreviation for station name, used in saveResults \cr 
#' paramShortName \tab string \tab Name of constituent, suitable for use in graphical headings \cr 
#' constitAbbrev \tab string \tab Abbreviation for constituent name, used in saveResults \cr 
#' drainSqKm \tab numeric \tab Drainage area in  km^2 \cr 
#' paStart \tab integer (1-12) \tab Starting month of period of analysis \cr 
#' paLong \tab integer (1-12) \tab Length of period of analysis in months \cr 
#' }
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water quality data
NULL


#' Example AnnualResults dataframe
#'
#' Example data representing annualResults-data
#'
#' @name exAnnualResults
#' @docType data
#' @format Data frame 
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water quality data
NULL

#' Example aResults dataframe
#'
#' Example data representing aResult-data
#'
#' @name exResultsBoot
#' @docType data
#' @format array
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water quality data
NULL