#' makeStars
#'
#' makeStars
#'
#' @param x number
#' @param conf vector
#' @keywords confidence intervals
#' @export
#' @examples
#' xVec <- runif(100, 5.0, 7.5)
#' conf <- estCI(xVec)
#' x <- 3
#' makeStars(x,conf)
makeStars<-function(x,conf){
  stars<- "**"
  stars<- if(x>conf[1] & x<conf[5]) "* " else stars
  stars<- if(x>conf[2] & x<conf[4]) "NS" else stars
  return(stars)
}