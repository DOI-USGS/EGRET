#' bootFNConcHist
#'
#' bootFNConcHist
#'
#' @param localAnnualResults dataframe
#' @param localResultsBoot array
#' @param localINFO dataframe
#' @param startYear integer
#' @param endYear integer
#' @param printTitle logical
#' @keywords confidence intervals
#' @export
#' @examples
#' AnnualResults <- exAnnualResults
#' aResults <- exResultsBoot
#' INFO <- exINFO
#' startYear <- 1990
#' endYear <- 2005
#' bootFNConcHist(startYear=startYear,endYear=endYear)
bootFNConcHist<-function(localAnnualResults=AnnualResults,localResultsBoot=aResults,
                         startYear,endYear,localINFO=INFO,printTitle=TRUE) {
  dimYears<-dim(localAnnualResults)[1]
  dimIter<-dim(localResultsBoot)[3]
  #  startY is the year index of the base year for all of the trend amounts
  #  endY is the year index of the last year for the trend amounts
  offsetYear<-trunc(localAnnualResults[1,1])
  startYear<-trunc(startYear)
  endYear<-trunc(endYear)
  startY<-startYear-offsetYear+1
  endY<-endYear-offsetYear+1
  #     set up the arrays to be plotted
  numYears <- endY - startY + 1
  #	cat("\nnumYears",numYears,endY,startY)
  xVals <- seq(startYear,endYear)
  y1 <- rep(0,numYears)
  y2 <- rep(0,numYears)
  y3 <- rep(0,numYears)
  change <- rep(0,numYears)
  #     compute the trend amounts (non-bootstrap)
  baseConc <- localAnnualResults[startY,5]
  y2 <- 100*(localAnnualResults[startY:endY,5] - baseConc)/baseConc
  #	cat("\n",y2)
  #       firstY is the index of the first year after the start year
  firstY <- startY + 1
  for(i in firstY:endY) {
    indexY <- i - startY + 1
    for(j in 1:dimIter) {
      change[j] <- (localResultsBoot[i,5,j]-localResultsBoot[startY,5,j])/localResultsBoot[startY,5,j]			
    }
    conf<-estCI(change)
    y1[indexY] <- 100*conf[1]
    y3[indexY] <- 100*conf[5]}
  #	cat("\n y1",y1)
  #	cat("\n y3",y3)
  par(oma = c(3, 0, 3, 0))
  par(mar = c(5, 6, 5, 2))		
  ymax <- max(y1,y2,y3)
  ymin <- min(y1,y2,y3)
  yTicks <- pretty(c(ymin,ymax))
  numYTicks <- length(yTicks)
  yBottom <- yTicks[1]
  yTop <- yTicks[numYTicks]
  xTicks <- pretty(c(startYear,endYear))
  numXTicks <- length(xTicks)
  xLeft <- xTicks[1]
  xRight <- xTicks[numXTicks]
  ylabel = "\nChange since starting year in %"
  periodName <- setSeasonLabel(localAnnualResults = localAnnualResults)
  title3 <- 
    "\nFlow Normalized Concentration & 95% CI, "
  
  title <- if (printTitle) {
    paste(localINFO$shortName, " ", localINFO$paramShortName, 
          "\n", periodName, title3," % change since",startYear)
  } else {
    ""
  }
  
  plot(xVals, y2, axes = FALSE, xlim = c(xLeft, 
                                         xRight), xaxs = "i", xlab = "", ylim = c(yBottom, yTop), yaxs = "i", 
       ylab = ylabel, main = title, pch = 20, cex = 1.0, cex.main = 1.1, 
       cex.lab = 1.2, font = 2, type = "l", lwd=3)
  par(new=TRUE)
  plot(xVals, y1, axes = FALSE, xlim = c(xLeft, 
                                         xRight), xaxs = "i", xlab = "", ylim = c(yBottom, yTop), yaxs = "i", 
       ylab = "", main = "", pch = 20, cex = 1.0, cex.main = 1.1, 
       cex.lab = 1.2, font = 2, type = "l", lwd = 1)
  par(new=TRUE)
  plot(xVals, y3, axes = FALSE, xlim = c(xLeft, 
                                         xRight), xaxs = "i", xlab = "", ylim = c(yBottom, yTop), yaxs = "i", 
       ylab = "", main = "", pch = 20, cex = 1.0, cex.main = 1.1, 
       cex.lab = 1.2, font = 2, type = "l", lwd = 1)
  abline(h=0,lty=2,lwd = 2)
  axis(1, tcl = 0.5, at = xTicks, labels = xTicks)
  axis(2, tcl = 0.5, las = 1, at = yTicks, cex.axis = 1.1)
  axis(3, tcl = 0.5, at = xTicks, labels = FALSE)
  axis(4, tcl = 0.5, at = yTicks, labels = FALSE)
  box()
  par(oma = c(0, 0, 0, 0))
  par(mar = c(5, 4, 4, 2) + 0.1)
  
  
  
}