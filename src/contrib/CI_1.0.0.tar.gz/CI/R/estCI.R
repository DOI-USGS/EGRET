#' estCI
#'
#' The returned vector conf contains the lower 95, lower 90, median, upper 90, and upper 95 percent CI bounds 
#'
#' @param x numeric vector whose sample quantiles are wanted, or an object of a class for which a method has been.
#' NA and NaN values are not allowed in numeric vectors unless na.rm is TRUE.
#' @param probs vector of returned probabilities
#' @param type an integer between 1 and 9 selecting one of the nine quantile algorithms detailed below to be used.
#' @param \dots further arguments passed to or from other methods
#' @return conf vector contains lower 95, lower 90, median, upper 90, and upper 95 percent CI bounds 
#' @keywords confidence intervals
#' @seealso quantile {stats}
#' @export
#' @importFrom stats quantile
#' @examples
#' x <- runif(100, 5.0, 7.5)
#' conf <- estCI(x)
estCI<-function(x,probs=c(0.025,0.05,0.5,0.95,0.975),type=5,...) {
  # the returned vector conf contains the lower 95, lower 90, median, upper 90, and upper 95 percent CI bounds  
  theta<-quantile(x,probs,type=type,...)
  conf<-rep(NA,5)
  med<-theta[3]
  med2<-2*med
  conf[3]<-med
  conf[1]<-med2-theta[5]
  conf[5]<-med2-theta[1]
  conf[2]<-med2-theta[4]
  conf[4]<-med2-theta[2]
  return(conf)
}