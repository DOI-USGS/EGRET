#' makeBootResults
#'
#' sets up a matrix containing the Annual Results and bootstrap confidence intervals on them
#'  the matrix is AnnualCI which is dimensioned, [years,8,5]
#'   second dimension corresponds to the 8 columns of Annual Results
#'       these are 1 DecYear, 2 Q, 3 Conc, 4 Flux, 5 FNConc, 6 FNFlux, 7 PeriodLong, 8 PeriodStart
#'   third dimension corresponds to 0.025, 0.05, mean, 0.95, and 0.975 values
#'
#' @param paLong numeric 
#' @param paStart numeric
#' @param localAnnualResults dataframe
#' @param localaResults array
#' @param type integer
#' @return AnnualCI array
#' @keywords confidence intervals
#' @seealso quantile {stats}
#' @export
#' @examples
#' AnnualResults <- exAnnualResults
#' aResults <- exResultsBoot
#' AnnualCI <- makeBootResults()
makeBootResults<-function (paLong = 12, paStart = 10, 
                           localAnnualResults = AnnualResults, localaResults = aResults, type = 5){
  # sets up a matrix containing the Annual Results and bootstrap confidence intervals on them
  #  the matrix is AnnualCI which is dimensioned, [years,8,5]
  #   second dimension corresponds to the 8 columns of Annual Results
  #       these are 1 DecYear, 2 Q, 3 Conc, 4 Flux, 5 FNConc, 6 FNFlux, 7 PeriodLong, 8 PeriodStart
  #   third dimension corresponds to 0.025, 0.05, mean, 0.95, and 0.975 values
  numYears <- length(localAnnualResults$DecYear)
  blankConf <- rep(NA,5)
  AnnualCI <- rep(NA, numYears*8*5)
  dim(AnnualCI) <- c(numYears,8,5)
  AnnualCI[,1,]<-localAnnualResults$DecYear
  AnnualCI[,2,]<-localAnnualResults$Q
  AnnualCI[,3,3]<-localAnnualResults$Conc
  AnnualCI[,4,3]<-localAnnualResults$Flux
  AnnualCI[,5,3]<-localAnnualResults$FNConc
  AnnualCI[,6,3]<-localAnnualResults$FNFlux
  AnnualCI[,7,]<-localAnnualResults$PeriodLong
  AnnualCI[,8,]<-localAnnualResults$PeriodStart
  for (i in 1:numYears) {
    for (j in 3:6) {
      x<-localaResults[i,j,]
      conf<-if(is.na(AnnualCI[i,j,3])) blankConf else estCI(x,type=type)
      AnnualCI[i,j,1]<-conf[1]
      AnnualCI[i,j,2]<-conf[2]
      AnnualCI[i,j,4]<-conf[4]
      AnnualCI[i,j,5]<-conf[5] 
    } 
  }
  return(AnnualCI)
}