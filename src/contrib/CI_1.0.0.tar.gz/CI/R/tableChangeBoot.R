#' tableChangeBoot
#'
#' tableChangeBoot
#'
#' @param fluxUnit number
#' @param localAnnualResults dataframe
#' @param localBoot array
#' @param localINFO dataframe
#' @param yearPoints vector
#' @keywords confidence intervals
#' @export
#' @examples
#' AnnualResults <- exAnnualResults
#' aResults <- exResultsBoot
#' INFO <- exINFO
#' AnnualCI <- makeBootResults()
#' tableChangeBoot(localBoot = aResults)
tableChangeBoot<-function (localAnnualResults = AnnualResults, localBoot = aResultsBoot, localINFO = INFO, 
                           fluxUnit = 9, yearPoints = NA) {
  if (is.numeric(fluxUnit)) {
    fluxUnit <- fluxConst[shortCode = fluxUnit][[1]]
  }
  else if (is.character(fluxUnit)) {
    fluxUnit <- fluxConst[fluxUnit][[1]]
  }
  firstYear <- trunc(localAnnualResults$DecYear[1])
  numYears <- length(localAnnualResults$DecYear)
  lastYear <- trunc(localAnnualResults$DecYear[numYears])
  defaultYearPoints <- seq(lastYear, firstYear, -5)
  numPoints <- length(defaultYearPoints)
  defaultYearPoints[1:numPoints] <- defaultYearPoints[numPoints:1]
  yearPoints <- if (is.na(yearPoints[1])) 
    defaultYearPoints
  else yearPoints
  numPoints <- length(yearPoints)
  yearPoints <- if (yearPoints[numPoints] > lastYear) 
    defaultYearPoints
  else yearPoints
  yearPoints <- if (yearPoints[1] < firstYear) 
    defaultYearPoints
  else yearPoints
  numPoints <- length(yearPoints)
  fluxFactor <- fluxUnit@unitFactor
  fName <- fluxUnit@shortName
  cat("\n  ", localINFO$shortName, "\n  ", localINFO$paramShortName)
  periodName <- setSeasonLabel(localAnnualResults = localAnnualResults)
  cat("\n  ", periodName, "\n")
  header1 <- "\n           Concentration trends\n   time span       change     slope    change     slope   sig\n                     mg/L   mg/L/yr        %       %/yr"
  header2 <- "\n\n\n                 Flux Trends\n   time span          change        slope       change        slope   sig"
  blankHolder <- "      ---"
  results <- rep(NA, 4)
  indexPoints <- yearPoints - firstYear + 1
  numPointsMinusOne <- numPoints - 1
  write(header1, file = "")
  for (iFirst in 1:numPointsMinusOne) {
    xFirst <- indexPoints[iFirst]
    yFirst <- localAnnualResults$FNConc[indexPoints[iFirst]]
    bFirst <- localBoot[indexPoints[iFirst],5,]
    iFirstPlusOne <- iFirst + 1
    for (iLast in iFirstPlusOne:numPoints) {
      xLast <- indexPoints[iLast]
      yLast <- localAnnualResults$FNConc[indexPoints[iLast]]
      bLast <- localBoot[indexPoints[iLast],5,]
      xDif <- xLast - xFirst
      yDif <- yLast - yFirst
      bDif <- bLast - bFirst
      conf <- estCI(bDif)
      resultStars <- makeStars(0,conf)
      results[1] <- if (is.na(yDif)) 
        blankHolder
      else format(yDif, digits = 2, width = 9)
      results[2] <- if (is.na(yDif)) 
        blankHolder
      else format(yDif/xDif, digits = 2, width = 9)
      results[3] <- if (is.na(yDif)) 
        blankHolder
      else format(100 * yDif/yFirst, digits = 2, width = 9)
      results[4] <- if (is.na(yDif)) 
        blankHolder
      else format(100 * yDif/yFirst/xDif, digits = 2, width = 9)
      cat("\n", yearPoints[iFirst], " to ", yearPoints[iLast], 
          results,"  ",resultStars)
    }
  }
  write(header2, file = "")
  cat("              ", fName, fName, "/yr      %         %/yr")
  for (iFirst in 1:numPointsMinusOne) {
    xFirst <- indexPoints[iFirst]
    yFirst <- localAnnualResults$FNFlux[indexPoints[iFirst]] * 
      fluxFactor
    bFirst <- localBoot[indexPoints[iFirst],6,] * fluxFactor
    iFirstPlusOne <- iFirst + 1
    for (iLast in iFirstPlusOne:numPoints) {
      xLast <- indexPoints[iLast]
      yLast <- localAnnualResults$FNFlux[indexPoints[iLast]] * 
        fluxFactor
      bLast <- localBoot[indexPoints[iLast],6,] * fluxFactor
      xDif <- xLast - xFirst
      yDif <- yLast - yFirst
      bDif <- bLast - bFirst
      conf <- estCI(bDif)
      resultStars <- makeStars(0,conf)
      results[1] <- if (is.na(yDif)) 
        blankHolder
      else format(yDif, digits = 2, width = 12)
      results[2] <- if (is.na(yDif)) 
        blankHolder
      else format(yDif/xDif, digits = 2, width = 12)
      results[3] <- if (is.na(yDif)) 
        blankHolder
      else format(100 * yDif/yFirst, digits = 2, width = 12)
      results[4] <- if (is.na(yDif)) 
        blankHolder
      else format(100 * yDif/yFirst/xDif, digits = 2, width = 12)
      cat("\n", yearPoints[iFirst], " to ", yearPoints[iLast], 
          results,"  ",resultStars)
    }
  }
  cat("\n\n\n Significance of trend:  ** alpha = 0.05,  * alpha = 0.10,  NS not significant")
}