####################################################
# Only do once:
#This is Laura's fork:
install.packages("//IGSARMEWFSAPA/projects/QW Monitoring Team/R_fxns/GSHydroTools_1.0.2.tar.gz", repo=NULL, type="source")
#Latest dataRetrieval:
install.packages("//IGSARMEWFSAPA/projects/QW Monitoring Team/R_fxns/dataRetrieval_1.3.2.tar.gz", repo=NULL, type="source")

#####################################################
library(dataRetrieval)
library(GSHydroTools)

siteListPhos <- getNWISSites(stateCd="OH",parameterCd="00665")
#Let's limit it to streams:
siteListPhos <- siteListPhos[siteListPhos$site_tp_cd == "ST",]
siteListPhos <- cbind(siteListPhos,data.frame(count=rep(NA,nrow(siteListPhos)),
                                              startDate=rep(as.Date("1888-01-01"),nrow(siteListPhos)),
                                              endDate=rep(as.Date("1888-01-01"),nrow(siteListPhos))))
for(i in siteListPhos$site_no){
  cat(i,"\n")
  siteData <- getDataAvailability(i, type="qw")
  phosData <- siteData[siteData$parameter_cd == "00665",c("count","startDate","endDate")]
  siteListPhos[siteListPhos$site_no == i,c("count","startDate","endDate")] <- phosData
}

siteListPhosHiCounts <- siteListPhos[siteListPhos$count >= 50 ,]

# Toledo, OH:
ymin <- min(as.numeric(siteListPhosHiCounts$dec_lat_va, na.rm = TRUE))-.5
ymax <- max(as.numeric(siteListPhosHiCounts$dec_lat_va, na.rm = TRUE))+.5
xmin <- min(as.numeric(siteListPhosHiCounts$dec_long_va, na.rm = TRUE))-1
xmax <- max(as.numeric(siteListPhosHiCounts$dec_long_va, na.rm = TRUE))+1
mainTitle <- "Ohio Sampling Sites"

df <- data.frame(lat=as.numeric(siteListPhosHiCounts$dec_lat_va),
                 lon=as.numeric(siteListPhosHiCounts$dec_long_va),
                 stringsAsFactors = FALSE)
latVar <- "lat"
lonVar <- "lon"
MapLocations(df,latVar,lonVar,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,
             includeLabels=FALSE)
