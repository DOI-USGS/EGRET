####################################################
# Only do once:
#This is Laura's fork:
install.packages("//IGSARMEWFSAPA/projects/QW Monitoring Team/R_fxns/GSHydroTools_1.0.2.tar.gz", repo=NULL, type="source")
#Latest dataRetrieval:
install.packages("//IGSARMEWFSAPA/projects/QW Monitoring Team/R_fxns/dataRetrieval_1.3.2.tar.gz", repo=NULL, type="source")

#####################################################
library(dataRetrieval)
library(EGRET)
library(GSHydroTools)

siteListPhos <- getNWISSites(stateCd="OH",parameterCd="00665")
#Let's limit it to streams:
siteListPhos <- siteListPhos[siteListPhos$site_tp_cd == "ST",]
siteListPhos <- cbind(siteListPhos,data.frame(count=rep(NA,nrow(siteListPhos)),
                  startDate=rep(as.Date("1888-01-01"),nrow(siteListPhos)),
                  endDate=rep(as.Date("1888-01-01"),nrow(siteListPhos))))
for(i in siteListPhos$site_no){
  cat(i,"\n")
  siteData <- getDataAvailability(i, type="qw")
  phosData <- siteData[siteData$parameter_cd == "00665",c("count","startDate","endDate")]
  siteListPhos[siteListPhos$site_no == i,c("count","startDate","endDate")] <- phosData
}

siteListPhosHiCounts <- siteListPhos[siteListPhos$count >= 50 ,]

# Toledo, OH:
ymin <- min(as.numeric(siteListPhosHiCounts$dec_lat_va, na.rm = TRUE))-.5
ymax <- max(as.numeric(siteListPhosHiCounts$dec_lat_va, na.rm = TRUE))+.5
xmin <- min(as.numeric(siteListPhosHiCounts$dec_long_va, na.rm = TRUE))-1
xmax <- max(as.numeric(siteListPhosHiCounts$dec_long_va, na.rm = TRUE))+1
mainTitle <- "Ohio Sampling Sites"

df <- data.frame(lat=as.numeric(siteListPhosHiCounts$dec_lat_va),
                 lon=as.numeric(siteListPhosHiCounts$dec_long_va),
                 stringsAsFactors = FALSE)
latVar <- "lat"
lonVar <- "lon"
MapLocations(df,latVar,lonVar,
             xmin,xmax,ymin,ymax,mainTitle=mainTitle,
             includeLabels=FALSE)











site <- "04193500"
dataAvailable <- getDataAvailability(site,type="qw")
phos <- dataAvailable[grep("hosphorus",dataAvailable$srsname),]
pCode <- "00665"

Sample <- getSampleData(site,pCode,"","")
Daily <- getDVData(site,"00060",
                   as.character(min(Sample$Date,na.rm = TRUE)),
                   as.character(max(Sample$Date,na.rm = TRUE)))

Daily <- Daily[as.Date(Daily$Date) < as.Date("2014-01-28"),]
Sample <- Sample[as.Date(Sample$Date) < as.Date("2014-01-28"),]
Sample <- mergeReport()

INFO<- getMetaData(site,pCode,interactive = FALSE)
modelEstimation()

DailyFull <- getDVData(site,"00060","1920-01-01","")
DailyFull <- DailyFull[as.Date(DailyFull$Date) < as.Date("2014-01-28"),]

saveResults("")

##########################################################################
load("D:/LADData/RCode/EGRET/NA.Phosphorus.RData")

sites <- getWQPSites(characteristicName="Phosphorus",within="10",
                     lat="41.5918",long="-83.5977")

#Flow history graphs:
annualSeries <- makeAnnualSeries(localDaily=DailyFull)
plotQTimeDaily(localDaily = DailyFull, qUnit = 3, qLower=30)
plotFour(qUnit=3,localDaily = DailyFull)
plotFourStats(qUnit=3)

plotQTimeDaily(qUnit = 3, qLower=30)
annualSeries <- makeAnnualSeries()
plotFour(qUnit=3)
plotFourStats(qUnit=3)

# Check sample data:
multiPlotDataOverview()
fluxBiasMulti(qUnit = 3,fluxUnit = 4)


plotConcTimeDaily(concMax = 2)
plotFluxTimeDaily(fluxUnit = 4)

plotConcPred()
plotFluxPred()
plotResidPred()
plotResidQ()
plotResidTime()
boxResidMonth()
boxConcThree()

plotConcHist()
plotFluxHist()
