#' Produces annual series of 8 streamflow statistics (and a lowess smooth of them) from daily streamflow data
#'
#' Part of the flowHistory system.  The data come from Daily and INFO data frames. 
#' Note that the function setPA must be run before this to establish the period of analysis (e.g. water year).
#'
#' \tabular{ll}{
#' istat  \tab Name  \cr
#' 1 \tab 1-day minimum discharge \cr 
#' 2 \tab 7-day minimum discharge \cr 
#' 3 \tab 30-day minimum discharge \cr 
#' 4 \tab median discharge \cr 
#' 5 \tab mean discharge \cr 
#' 6 \tab 30-day maximum discharge \cr 
#' 7 \tab 7-day maximum discharge \cr 
#' 8 \tab 1-day maximum discharge \cr  
#' }
#'
#' @param localDaily data frame that contains the daily streamflow data
#' @param localINFO data frame that contains the metadata
#' @param edgeAdjust logical specifying whether to use the modified method for calculating the windows at the edge of the record.  The modified method tends to reduce curvature near the start and end of record.  Default is TRUE.
#' @keywords statistics streamflow trends
#' @export
#' @return annualSeries data frame that contains the annual series of streamflow statistics
#' @examples 
#' Daily <- ChopDaily
#' INFO <- ChopINFO
#' annualSeries <- makeAnnualSeries()
makeAnnualSeries<-function(localDaily = Daily, localINFO = INFO, edgeAdjust = TRUE) {
  
  if (sum(c("paStart", "paLong", "window") %in% names(localINFO)) == 
        3) {
    paLong <- localINFO$paLong
    paStart <- localINFO$paStart
    window <- localINFO$window
  } else {
    paLong <- 12
    paStart <- 10
    window <- 30
  }
  numDays <- length(localDaily$DecYear)
  yearFirst <- trunc(localDaily$DecYear[1])
  yearLast <- trunc(localDaily$DecYear[numDays])
  monthSeqFirst <- localDaily$MonthSeq[1]
  monthSeqLast <- localDaily$MonthSeq[numDays]
  numYears <- yearLast - yearFirst + 2
  annualSeries <- rep(NA, 3 * 8 * numYears)
  dim(annualSeries) <- c(3, 8, numYears)
  paStartLow <- if (paLong == 12 & paStart == 10) 4 else paStart
  Starts <- seq(paStartLow, monthSeqLast, 12)
  Ends <- Starts + paLong - 1
  startEndSeq <- data.frame(Starts, Ends)
  startEndSeq <- subset(startEndSeq, (Ends >= monthSeqFirst) & (Starts <= monthSeqLast))
  numYSeq <- length(startEndSeq$Ends)
  
  for (i in 1:numYSeq) {
    startSeq <- startEndSeq$Starts[i]
    endSeq <- startEndSeq$Ends[i]
    yearDaily <- subset(localDaily, (MonthSeq >= startSeq) & (MonthSeq <= endSeq))
    
    goodDay <- length(yearDaily$Q) - sum(is.na(yearDaily$Q))
    
    if (goodDay > 26 * paLong){
      annualSeries[1, 1:3, i] <- mean(yearDaily$DecYear,na.rm = TRUE)
      annualSeries[2, 1, i] <- min(yearDaily$Q, na.rm = TRUE) 
      annualSeries[2, 2, i] <- min(yearDaily$Q7, na.rm = TRUE) 
      annualSeries[2, 3, i] <- min(yearDaily$Q30, na.rm = TRUE)         
    }
    
  }
  Starts <- seq(paStart, monthSeqLast, 12)
  Ends <- Starts + paLong - 1
  startEndSeq <- data.frame(Starts, Ends)
  startEndSeq <- subset(startEndSeq, (Ends >= monthSeqFirst) & (Starts <= monthSeqLast))
  numYSeq <- length(startEndSeq$Ends)
  for (i in 1:numYSeq) {
    startSeq <- startEndSeq$Starts[i]
    endSeq <- startEndSeq$Ends[i]
    yearDaily <- subset(localDaily, (MonthSeq >= startSeq) & (MonthSeq <= endSeq))
    
    goodDay <- length(yearDaily$Q) - sum(is.na(yearDaily$Q))
    
    if(goodDay > 26 * paLong){
      annualSeries[1, 4:8, i] <- mean(yearDaily$DecYear, na.rm = TRUE)
      annualSeries[2, 4, i] <- median(yearDaily$Q, na.rm = TRUE)
      annualSeries[2, 5, i] <- mean(yearDaily$Q, na.rm = TRUE)
      annualSeries[2, 6, i] <- max(yearDaily$Q30, na.rm = TRUE)
      annualSeries[2, 7, i] <- max(yearDaily$Q7, na.rm = TRUE)
      annualSeries[2, 8, i] <- max(yearDaily$Q, na.rm = TRUE)       
    }
  }
  for (istat in 1:8) {
    x <- annualSeries[1, istat, ]
    y <- log(annualSeries[2, istat, ])
    originalYear <- x
    numYear <- length(x)
    xy <- data.frame(x, y)
    xy <- na.omit(xy)
    numXY <- length(xy$x)
    x <- xy$x
    newYear <- x
    numNewYear <- length(newYear)
    x1 <- newYear[1]
    xn <- newYear[numNewYear]
    orYear <- originalYear[1:numNewYear]
    diff <- newYear - orYear
    meanDiff <- mean(diff, na.rm = TRUE)
    offset <- round(meanDiff)
    for (i in 1:numXY) {
      xi <- x[i]
      distToEdge <- min((xi - x1),(xn - xi))
      close <- (distToEdge < window)
      thisWindow <- if(edgeAdjust & close) (2*window) - distToEdge else window
      w <- triCube(x - xi, thisWindow)
      mod <- lm(xy$y ~ x, weights = w)
      new <- data.frame(x = x[i])
      z <- exp(predict(mod, new))
      ioffset <- i + offset
      annualSeries[3, istat, ioffset] <- z
    }
  }
  return(annualSeries)
}