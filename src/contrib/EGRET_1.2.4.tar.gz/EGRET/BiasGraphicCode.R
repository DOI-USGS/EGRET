# This file contains all the code for the flux bias graphs - eight graphs
#  26Feb2013
fluxBiasEight<-function (localSample = Sample, localDaily = Daily, localINFO = INFO, 
    qUnit = 2, fluxUnit = 3, moreTitle = "") 
{
    postscript(file="eight",width=8,height=10,horizontal=FALSE,family="Helvetica")
    layout(rbind(c(1, 2), c(3, 4), c(5, 6), c(7,8)), heights = c(1, 1), 
        width = c(1.5, 1.5), respect = rbind(c(0, 0), c(0, 0), 
            c(0, 0), c(0,0)))
    par(oma = c(0, 6.8, 4, 6.8))
    plotResidLogP(localSample = localSample, localINFO = localINFO, stdResid = FALSE, tinyPlot=TRUE, printTitle = FALSE)
    plotResidQsmall(localSample = localSample, localINFO = localINFO, 
        qUnit, tinyPlot = TRUE, printTitle = FALSE)
    plotResidDec(localSample = localSample, localINFO = localINFO, printTitle = FALSE)
    boxResidM(localSample = localSample, localINFO = localINFO, printTitle = FALSE)
    boxConc3(localSample = localSample, localDaily = localDaily, localINFO = localINFO, printTitle=FALSE)
    plotConcPredSmall(localSample = localSample, localINFO=localINFO, printTitle=FALSE)
    boxQTw(localSample = localSample, localDaily = localDaily, localINFO = localINFO, printTitle = FALSE, qUnit = qUnit)
        plotFluxP(localSample = localSample, localINFO = localINFO, 
        fluxUnit, tinyPlot = TRUE, printTitle = FALSE)
        fluxBias <- fluxBiasStat(localSample = localSample)
    fB <- as.numeric(fluxBias[3])
    fB <- format(fB, digits = 3)
    title <- paste(localINFO$shortName, " ", localINFO$paramShortName, 
        "\nModel is",moreTitle, "  Flux Bias Statistic", fB)
    mtext(title, cex = 1.2, outer = TRUE, font = 2)
    par(mfcol = c(1, 1), oma = c(0, 0, 0, 0))
    dev.off()
}
#
#
fluxBiasGraphs<-function (localSample = Sample, localDaily = Daily, localINFO = INFO, 
    qUnit = 2, fluxUnit = 3, moreTitle = "") 
{
    layout(rbind(c(1, 2), c(3, 4), c(5, 6)), heights = c(1, 1), 
        width = c(1.5, 1.5), respect = rbind(c(0, 0), c(0, 0), 
            c(0, 0)))
    par(oma = c(0, 6.8, 4, 6.8))
    plotResidLogP(localSample = localSample, localINFO = localINFO, stdResid = FALSE, tinyPlot=TRUE, printTitle = FALSE)
    plotResidQsmall(localSample = localSample, localINFO = localINFO, 
        qUnit, tinyPlot = TRUE, printTitle = FALSE)
    plotResidDec(localSample = localSample, localINFO = localINFO, printTitle = FALSE)
    boxResidM(localSample = localSample, localINFO = localINFO, printTitle = FALSE)
    boxQTw(localSample = localSample, localDaily = localDaily, localINFO = localINFO, printTitle = FALSE, qUnit = qUnit)
        plotFluxP(localSample = localSample, localINFO = localINFO, 
        fluxUnit, tinyPlot = TRUE, printTitle = FALSE)
        fluxBias <- fluxBiasStat(localSample = localSample)
    fB <- as.numeric(fluxBias[3])
    fB <- format(fB, digits = 3)
    title <- paste(localINFO$shortName, " ", localINFO$paramShortName, 
        "\nModel is",moreTitle, "  Flux Bias Statistic", fB)
    mtext(title, cex = 1.2, outer = TRUE, font = 2)
    par(mfcol = c(1, 1), oma = c(0, 0, 0, 0))
}
#
#
plotResidLogP<-function (localSample = Sample, localINFO = INFO, stdResid = FALSE, 
    tinyPlot = FALSE, printTitle = TRUE) 
{
    if (tinyPlot) 
        par(mar = c(5, 4, 1, 1))
    else par(mar = c(5, 4, 4, 2) + 0.1)
    x <- localSample$yHat
    yLow <- log(localSample$ConcLow) - localSample$yHat
    yHigh <- log(localSample$ConcHigh) - localSample$yHat
    yLow <- if (stdResid) 
        yLow/localSample$SE
    else yLow
    yHigh <- if (stdResid) 
        yHigh/localSample$SE
    else yHigh
    Uncen <- localSample$Uncen
    xMin <-  min(x) - 0.1
    xMax <- max(x) + 0.1
    maxYHigh <- max(yHigh) + 0.1
    minYLow <- min(yLow, na.rm = TRUE) - 0.5
    xSpan <- c(xMin,xMax)
    xTicks <- pretty(xSpan,n=4)
    numXTicks <- length(xTicks)
    xLeft <- xTicks[1]
    xRight <- xTicks[numXTicks]
    ySpan <- c(minYLow, maxYHigh)
    yTicks <- pretty(ySpan, n = 5)
    numYTicks <- length(yTicks)
    yBottom <- yTicks[1]
    yTop <- yTicks[numYTicks]
    xLab <- "Predicted log concentration"
    yLab <- if (stdResid) 
        "Standardized Residual in natural log units"
    else "Residual"
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, "\n", localINFO$paramShortName, 
            "\n", "Residual versus Estimated Concentration")
    else ""
    plot(x, yHigh, axes = FALSE, xlim = c(xLeft,xRight), xaxs = "i", xlab = xLab, ylim = c(yBottom, 
        yTop), yaxs = "i", ylab = yLab, main = plotTitle, pch = 20, 
        cex = 0.6, cex.main = 1.3, font.main = 2, cex.lab = 1.2)
    axis(1, tcl = 0.5, at = xTicks, labels = xTicks)
    axis(2, tcl = 0.5, las = 1, at = yTicks, labels = yTicks)
    axis(3, tcl = 0.5, at = xTicks, labels = FALSE)
    axis(4, tcl = 0.5, at = yTicks, labels = FALSE)
    box()
    yLowVal <- ifelse(is.na(yLow), yBottom, yLow)
    numSamples <- length(x)
    uncensoredIndex <- 1:numSamples
    uncensoredIndex <- uncensoredIndex[Uncen == 0]
    segments(x[uncensoredIndex], yLowVal[uncensoredIndex], 
        x[uncensoredIndex], yHigh[uncensoredIndex])
    abline(h = 0)
    par(mar = c(5, 4, 4, 2) + 0.1)
}
#
#
plotResidQsmall<-function (localSample = Sample, localINFO = INFO, qUnit = 2, 
    tinyPlot = FALSE, stdResid = FALSE, printTitle = TRUE) 
{
    if (tinyPlot) 
        par(mar = c(5, 4, 1, 1))
    else par(mar = c(5, 4, 4, 2) + 0.1)
    if (is.numeric(qUnit)) {
        qUnit <- qConst[shortCode = qUnit][[1]]
    }
    else if (is.character(qUnit)) {
        qUnit <- qConst[qUnit][[1]]
    }
    qFactor <- qUnit@qUnitFactor
    x <- localSample$Q * qFactor
    yLow <- log(localSample$ConcLow) - localSample$yHat
    yHigh <- log(localSample$ConcHigh) - localSample$yHat
    yLow <- if (stdResid) 
        yLow/localSample$SE
    else yLow
    yHigh <- if (stdResid) 
        yHigh/localSample$SE
    else yHigh
    Uncen <- localSample$Uncen
    xMin <- 0.95 * min(x)
    xMax <- 1.05 * max(x)
    maxYHigh <- max(yHigh) + 0.1
    minYLow <- min(yLow, na.rm = TRUE) - 0.5
    xTicks <- logPretty1(xMin, xMax)
    numXTicks <- length(xTicks)
    xLeft <- xTicks[1]
    xRight <- xTicks[numXTicks]
    ySpan <- c(minYLow, maxYHigh)
    yTicks <- pretty(ySpan, n = 4)
    numYTicks <- length(yTicks)
    yBottom <- yTicks[1]
    yTop <- yTicks[numYTicks]
    xLab <- qUnit@qUnitExpress
    yLab <- if (stdResid) 
        "Standardized Residual in natural log units"
    else "Residual"
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, "\n", localINFO$paramShortName, 
            "\n", "Residual versus Discharge")
    else ""
    plot(log(x, 10), yHigh, axes = FALSE, xlim = c(log(xLeft, 
        10), log(xRight, 10)), xaxs = "i", xlab = xLab, ylim = c(yBottom, 
        yTop), yaxs = "i", ylab = yLab, main = plotTitle, pch = 20, 
        cex = 0.6, cex.main = 1.3, font.main = 2, cex.lab = 1.2)
    axis(1, tcl = 0.5, at = log(xTicks, 10), labels = xTicks)
    axis(2, tcl = 0.5, las = 1, at = yTicks, labels = yTicks)
    axis(3, tcl = 0.5, at = log(xTicks, 10), labels = FALSE)
    axis(4, tcl = 0.5, at = yTicks, labels = FALSE)
    box()
    yLowVal <- ifelse(is.na(yLow), yBottom, yLow)
    numSamples <- length(x)
    uncensoredIndex <- 1:numSamples
    uncensoredIndex <- uncensoredIndex[Uncen == 0]
    segments(log(x[uncensoredIndex], 10), yLowVal[uncensoredIndex], 
        log(x[uncensoredIndex], 10), yHigh[uncensoredIndex])
    abline(h = 0)
    par(mar = c(5, 4, 4, 2) + 0.1)
}
#
#
plotResidDec<-function (localSample = Sample, localINFO = INFO, stdResid = FALSE, printTitle = TRUE) 
{
    
        par(mar = c(5, 4, 1, 1))
        x <- localSample$DecYear
    yLow <- log(localSample$ConcLow) - localSample$yHat
    yHigh <- log(localSample$ConcHigh) - localSample$yHat
    yLow <- if (stdResid) 
        yLow/localSample$SE
    else yLow
    yHigh <- if (stdResid) 
        yHigh/localSample$SE
    else yHigh
    Uncen <- localSample$Uncen
    xMin <- min(x)-0.05
    xMax <- max(x)+0.05
    maxYHigh <- max(yHigh) + 0.1
    minYLow <- min(yLow, na.rm = TRUE) - 0.5
    xSpan<-c(xMin,xMax)
    xTicks <- pretty(xSpan,n=4)
    numXTicks <- length(xTicks)
    xLeft <- xTicks[1]
    xRight <- xTicks[numXTicks]
    ySpan <- c(minYLow, maxYHigh)
    yTicks <- pretty(ySpan, n = 4)
    numYTicks <- length(yTicks)
    yBottom <- yTicks[1]
    yTop <- yTicks[numYTicks]
    xLab <- "Time, in Years"
    yLab <- if (stdResid) 
        "Standardized Residual in natural log units"
    else "Residual"
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, "\n", localINFO$paramShortName, 
            "\n", "Residual versus Time")
    else ""
    plot(x, yHigh, axes = FALSE, xlim = c(xLeft, xRight), xaxs = "i", xlab = xLab, ylim = c(yBottom, 
        yTop), yaxs = "i", ylab = yLab, main = plotTitle, pch = 20, 
        cex = 0.6, cex.main = 1.3, font.main = 2, cex.lab = 1.2)
    axis(1, tcl = 0.5, at = xTicks, labels = xTicks)
    axis(2, tcl = 0.5, las = 1, at = yTicks, labels = yTicks)
    axis(3, tcl = 0.5, at = xTicks, labels = FALSE)
    axis(4, tcl = 0.5, at = yTicks, labels = FALSE)
    box()
    yLowVal <- ifelse(is.na(yLow), yBottom, yLow)
    numSamples <- length(x)
    uncensoredIndex <- 1:numSamples
    uncensoredIndex <- uncensoredIndex[Uncen == 0]
    segments(x[uncensoredIndex], yLowVal[uncensoredIndex], 
        x[uncensoredIndex], yHigh[uncensoredIndex])
    abline(h = 0)
    par(mar = c(5, 4, 4, 2) + 0.1)
}
#
#
boxResidM<-function (localSample = Sample, localINFO = INFO, printTitle = TRUE) 
{
    par(mar = c(5,4,1,1))
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, "\n", localINFO$paramShortName, 
            "\nBoxplots of residual values by month")
    else ""
    nameList <- sapply(c(1:12), function(x) {
        monthInfo[[x]]@monthAbbrev
    })
    namesListFactor <- factor(nameList, levels = nameList)
    monthList <- as.character(apply(localSample, 1, function(x) monthInfo[[as.numeric(x[["Month"]])]]@monthAbbrev))
    monthList <- factor(monthList, namesListFactor)
    localSample$Resid<-log(localSample$ConcAve)-localSample$yHat
    tempDF <- data.frame(month = monthList, conc = localSample$Resid)
    maxY <- 1.02 * max(localSample$Resid)
    minY <- 1.02 * min(localSample$Resid)
    ySpan <- c(minY, maxY)
    yTicks <- pretty(ySpan, n = 4)
    yMin <- yTicks[1]
    yMax <- yTicks[length(yTicks)]
    nameList<-c("J","F","M","A","M","J","J","A","S","O","N","D")
    boxplot(tempDF$conc ~ tempDF$month, ylim = c(yMin, yMax), yaxs = "i", 
        varwidth = TRUE, names = nameList, axes=FALSE, xlab = "Month", ylab = "Residual", 
        main = plotTitle, cex = 0.8, cex.axis = 1.1, cex.main = 1.2, las=2, 
        font.main = 2)
        axis(1,tcl=0.5,at=seq(1,12),labels=nameList)
        axis(2,tcl=0.5,las=1,at=yTicks)
        axis(3,tcl=0.5,at=seq(1,12),labels=FALSE)
        axis(4,tcl=0.5,at=yTicks,labels=FALSE)
        box()
        abline(h=0)
}
#
#
boxConc3<-function (localSample = Sample, localDaily = Daily, localINFO = INFO, 
    printTitle = TRUE, moreTitle = NA) 
{
    
    
    nS <- length(localSample$ConcAve)
    nD <- length(localDaily$ConcDay)
    index1 <- rep(1, nS)
    index2 <- rep(2, nS)
    index3 <- rep(3, nD)
    index <- c(index1, index2,index3)
    concV <- c(localSample$ConcAve,localSample$ConcHat,localDaily$ConcDay)
    yLab <- paste("Concentration in mg/L")
    name1 <- "Sampled day\nvalues"
    name2 <- "Sampled day\nestimates"
    name3 <- "All day\nestimates"
    groupNames <- c(name1,name2,name3)
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, ",", localINFO$paramShortName, 
            "\nComparison of distribution of sampled concentrations\nwith estimates on sampled days and on all days using ",moreTitle)
    else ""
    yMax<-max(concV)
    yTicks<-yPretty(yMax)
    yTop<-yTicks[length(yTicks)]
    boxplot(concV ~ index, ylim=c(0,yTop), yaxs="i", varwidth = TRUE, names = groupNames, axes=FALSE, 
        xlab = "", ylab = yLab, main = plotTitle, font.main = 2, 
        cex.main = 0.9, cex.axis = 0.6, cex.lab = 1.1)
        axis(1,tcl=0.5,at=c(1,2,3),labels=groupNames,cex.axis=0.8)
        axis(2,tcl=0.5,las=1,at=yTicks)
        axis(3,tcl=0.5,at=c(1,2,3),labels=FALSE)
        axis(4,tcl=0.5,at=yTicks,labels=FALSE)
        box()
}
#
#
plotConcPredSmall<-function (localSample = Sample, localINFO = INFO, concMax = NA, 
    printTitle = TRUE) 
{
    x <- localSample$ConcHat
    yLow <- localSample$ConcLow
    yHigh <- localSample$ConcHigh
    Uncen <- localSample$Uncen
    xMax <- 1.05 * max(x)
    maxYHigh <- if (is.na(concMax)) 
        1.05 * max(yHigh)
    else concMax
    xTicks <- yPretty(xMax)
    numXTicks <- length(xTicks)
    xLeft <- xTicks[1]
    xRight <- xTicks[numXTicks]
    yTicks <- yPretty(maxYHigh)
    numYTicks <- length(yTicks)
    yBottom <- yTicks[1]
    yTop <- yTicks[numYTicks]
    xLab <- "Estimated Concentration in mg/L"
    yLab <- "Observed Concentration"
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, "\n", localINFO$paramShortName, 
            "\n", "Observed versus Estimated Concentration")
    else ""
    plot(x, yHigh, axes = FALSE, xlim = c(xLeft, xRight), xaxs = "i", 
        xlab = xLab, ylim = c(yBottom, yTop), yaxs = "i", ylab = yLab, 
        main = plotTitle, pch = 20, cex = 0.7, cex.main = 1.3, 
        font.main = 2, cex.lab = 1.1)
    axis(1, tcl = 0.5, at = xTicks, labels = xTicks)
    axis(2, tcl = 0.5, las = 1, at = yTicks, labels = yTicks)
    axis(3, tcl = 0.5, at = xTicks, labels = FALSE)
    axis(4, tcl = 0.5, at = yTicks, labels = FALSE)
    box()
    yLowVal <- ifelse(is.na(yLow), yBottom, yLow)
    numSamples <- length(x)
    uncensoredIndex <- 1:numSamples
    uncensoredIndex <- uncensoredIndex[Uncen == 0]
    segments(x[uncensoredIndex], yLowVal[uncensoredIndex], x[uncensoredIndex], 
        yHigh[uncensoredIndex])
    abline(a = 0, b = 1)
}
#
#
boxQTw<-function (localSample = Sample, localDaily = Daily, localINFO = INFO, 
    printTitle = TRUE, qUnit = 2) 
{
    if (is.numeric(qUnit)) {
        qUnit <- qConst[shortCode = qUnit][[1]]
    }
    else if (is.character(qUnit)) {
        qUnit <- qConst[qUnit][[1]]
    }
    qFactor <- qUnit@qUnitFactor
    bigQ <- c(localSample$Q * qFactor, localDaily$Q * qFactor)
    yMin <- 0.99 * min(bigQ)
    yMax <- 1.01 * max(bigQ)
    yTicks <- logPretty1(yMin,yMax)
    numYTicks <- length(yTicks)
    yBottom <- yTicks[1]
    yTop <- yTicks[numYTicks]
    nS <- length(localSample$Q)
    nD <- length(localDaily$Q)
    index1 <- rep(1, nS)
    index2 <- rep(2, nD)
    index <- c(index1, index2)
    yLab <- paste("Discharge")
    groupNames <- c("Sampled Days", "All Days")
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, ",", localINFO$paramShortName, 
            "\nComparison of distribution of\nSampled Discharges and All Daily Discharges")
    else ""
    boxplot(log(bigQ,10) ~ index, varwidth = TRUE,  axes = FALSE,xlab = "", ylab = yLab, main = plotTitle, font.main = 2, ylim=c(log(yBottom,10),log(yTop,10)),yaxs="i", 
        cex.main = 1, cex.axis = 1.2, cex.lab = 1.2)
        axis(1, tcl = 0.5, at = seq(1,2), labels = groupNames)
        axis(2, tcl = 0.5, las = 1, at = log(yTicks,10), labels = yTicks)
        axis(3, tcl = 0.5, at = seq(1,2), labels = FALSE)
        axis(4, tcl = 0.5, at = log(yTicks,10), labels = FALSE)
        box()
}
#
#
plotFluxP<-function (localSample = Sample, localINFO = INFO, fluxUnit = 3, 
    fluxMax = NA, tinyPlot = FALSE, printTitle = TRUE) 
{
    if (is.numeric(fluxUnit)) {
        fluxUnit <- fluxConst[shortCode = fluxUnit][[1]]
    }
    else if (is.character(fluxUnit)) {
        fluxUnit <- fluxConst[fluxUnit][[1]]
    }
    if (tinyPlot) 
        par(mar = c(5, 5, 1, 1))
    else par(mar = c(5, 5, 4, 2) + 0.1)
    fluxFactor <- fluxUnit@unitFactor * 86.4
    x <- localSample$ConcHat * localSample$Q * fluxFactor
    yLow <- localSample$ConcLow * localSample$Q * fluxFactor
    yHigh <- localSample$ConcHigh * localSample$Q * fluxFactor
    Uncen <- localSample$Uncen
    xMax <- 1.05 * max(x)
    maxYHigh <- if (is.na(fluxMax)) 
        1.05 * max(yHigh)
    else fluxMax
    xTicks <- yPretty1(xMax)
    numXTicks <- length(xTicks)
    xLeft <- xTicks[1]
    xRight <- xTicks[numXTicks]
    yTicks <- yPretty1(maxYHigh)
    numYTicks <- length(yTicks)
    yBottom <- yTicks[1]
    yTop <- yTicks[numYTicks]
    xLab <- fluxUnit@unitEstimate
    yLab <- "Observed Flux"
    plotTitle <- if (printTitle) 
        paste(localINFO$shortName, "\n", localINFO$paramShortName, 
            "\n", "Observed vs Estimated Flux")
    else ""
    plot(x, yHigh, axes = FALSE, xlim = c(xLeft, xRight), xaxs = "i", 
        xlab = xLab, ylim = c(yBottom, yTop), yaxs = "i", ylab = yLab, 
        main = plotTitle, pch = 20, cex = 0.6, cex.main = 1.3, 
        font.main = 2, cex.lab = 1.2)
    axis(1, tcl = 0.5, at = xTicks, labels = xTicks)
    axis(2, tcl = 0.5, las = 1, at = yTicks, labels = yTicks)
    axis(3, tcl = 0.5, at = xTicks, labels = FALSE)
    axis(4, tcl = 0.5, at = yTicks, labels = FALSE)
    box()
    yLowVal <- ifelse(is.na(yLow), yBottom, yLow)
    numSamples <- length(x)
    uncensoredIndex <- 1:numSamples
    uncensoredIndex <- uncensoredIndex[Uncen == 0]
    segments(x[uncensoredIndex], yLowVal[uncensoredIndex], x[uncensoredIndex], 
        yHigh[uncensoredIndex])
    abline(a = 0, b = 1)
    par(mar = c(5, 4, 4, 2) + 0.1)
}
#
#
yPretty1<-function (yMax) 
{
    yPair <- c(0, yMax)
    yTicks <- pretty(yPair, n = 3)
    return(yTicks)
}
