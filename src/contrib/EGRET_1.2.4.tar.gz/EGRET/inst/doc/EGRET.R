### R code from vignette source 'EGRET.Rnw'

###################################################
### code chunk number 1: openLibrary
###################################################
library(xtable)
options(continue=" ")
options(width=60)
# options(SweaveHooks=list(fig=function()
#   par(mar=c(5.1,4.1,1.1,2.1),oma=c(0,0,0,0))))


###################################################
### code chunk number 2: openlibraries
###################################################
library(dataRetrieval)
library(EGRET)


###################################################
### code chunk number 3: cheatSheets
###################################################
printqUnitCheatSheet()


###################################################
### code chunk number 4: cheatSheets2
###################################################
printFluxUnitCheatSheet()


###################################################
### code chunk number 5: vignette1 (eval = FALSE)
###################################################
## vignette("dataRetrieval")


###################################################
### code chunk number 6: flowHistory
###################################################
#Rio Grande at Embudo, NM
siteID <- "08279500"  
startDate <- ""
endDate <- ""

Daily <- getDVData(siteID,"00060",startDate,endDate,interactive=FALSE)
INFO <- getMetaData(siteID,"",interactive=FALSE)
INFO$shortName <- "Rio Grande at Embudo, NM"


###################################################
### code chunk number 7: newChunckWinter (eval = FALSE)
###################################################
## INFO <- setPA(paStart=12,paLong=3)


###################################################
### code chunk number 8: newChunck
###################################################
INFO <- setPA()


###################################################
### code chunk number 9: newChunckAS (eval = FALSE)
###################################################
## annualSeries <- makeAnnualSeries()


###################################################
### code chunk number 10: plotFlow (eval = FALSE)
###################################################
## Daily <- getDVData(siteID,"00060",startDate,endDate,interactive=FALSE)
## INFO <- getMetaData(siteID,"",interactive=FALSE)
## INFO$shortName <- "Rio Grande at Embudo, NM"
## INFO <- setPA()
## annualSeries <- makeAnnualSeries()
## plotFlowSingle(istat=7,qUnit="thousandCfs")
## plotSDLogQ()
## plotQTimeDaily(1990,2010,qLower=1,qUnit=3)
## plotFour(qUnit=3)
## plotFourStats(qUnit=3)


###################################################
### code chunk number 11: plotFlowSingle
###################################################
annualSeries <- makeAnnualSeries()
plotFlowSingle(istat=7,qUnit="thousandCfs")


###################################################
### code chunk number 12: figplotFlowSingle
###################################################
annualSeries <- makeAnnualSeries()
plotFlowSingle(istat=7,qUnit="thousandCfs")


###################################################
### code chunk number 13: plotSDLogQ
###################################################
plotSDLogQ()


###################################################
### code chunk number 14: figplotSDLogQ
###################################################
plotSDLogQ()


###################################################
### code chunk number 15: plotQTimeDaily
###################################################
plotQTimeDaily(1990,2010,qLower=2,qUnit=3)


###################################################
### code chunk number 16: figplotQTimeDaily
###################################################
plotQTimeDaily(1990,2010,qLower=2,qUnit=3)


###################################################
### code chunk number 17: plotFour
###################################################
plotFour(qUnit=3)


###################################################
### code chunk number 18: figplotFour
###################################################
plotFour(qUnit=3)


###################################################
### code chunk number 19: plotFourStats
###################################################
plotFourStats(qUnit=3)


###################################################
### code chunk number 20: figplotFourStats
###################################################
plotFourStats(qUnit=3)


###################################################
### code chunk number 21: plotSDRed
###################################################
siteID <- "05082500"
DailyRed <- getDVData(siteID,"00060","","",interactive=FALSE)
INFORed <- getMetaData(siteID,"",interactive=FALSE)
INFORed$shortName <- "Red River, ND"
INFORed <- setPA(paStart=6, paLong=3,localINFO = INFORed)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed, printStaName = FALSE)


###################################################
### code chunk number 22: fig3a
###################################################
siteID <- "05082500"
DailyRed <- getDVData(siteID,"00060","","",interactive=FALSE)
INFORed <- getMetaData(siteID,"",interactive=FALSE)
INFORed$shortName <- "Red River, ND"
INFORed <- setPA(paStart=6, paLong=3,localINFO = INFORed)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed, printStaName = FALSE)


###################################################
### code chunk number 23: plotSDRed2
###################################################
INFORed <- setPA(paStart=3, paLong=3)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed)


###################################################
### code chunk number 24: fig3b
###################################################
INFORed <- setPA(paStart=3, paLong=3)
plotSDLogQ(localDaily = DailyRed, localINFO = INFORed)


###################################################
### code chunk number 25: printSeries (eval = FALSE)
###################################################
## printSeries(istat=3, qUnit=3)


###################################################
### code chunk number 26: printSeries
###################################################
annualSeries <- makeAnnualSeries()
tableFlowChange(istat=3, qUnit=3,yearPoints=c(1930,1950,1970,1990,2010))


###################################################
### code chunk number 27: wrtds1
###################################################
siteID <- "01491000" #Choptank River at Greensboro, MD
startDate <- "1979-10-01"
endDate <- "2011-09-30"
param<-"00631"
Daily <- getDVData(siteID,"00060",startDate,endDate)
INFO<- getMetaData(siteID,param,interactive=FALSE)
INFO$shortName <- "Choptank River"
INFO <- setPA()
annualSeries <- makeAnnualSeries()
Sample <- getSampleData(siteID,param,startDate,endDate)
Sample <- mergeReport()


###################################################
### code chunk number 28: plotList (eval = FALSE)
###################################################
## boxConcMonth()
## boxQTwice()
## plotLogConcTime()
## plotConcTime()
## plotConcQ()
## plotLogConcQ()
## plotLogFluxQ()
## multiPlotDataOverview()


###################################################
### code chunk number 29: boxConcMonth
###################################################
boxConcMonth()


###################################################
### code chunk number 30: figboxConcMonth
###################################################
boxConcMonth()


###################################################
### code chunk number 31: boxQTwice
###################################################
boxQTwice()


###################################################
### code chunk number 32: figboxQTwice
###################################################
boxQTwice()


###################################################
### code chunk number 33: plotConcTime
###################################################
plotConcTime()


###################################################
### code chunk number 34: figplotConcTime
###################################################
plotConcTime()


###################################################
### code chunk number 35: plotLogConcTime
###################################################
plotLogConcTime()


###################################################
### code chunk number 36: figplotLogConcTime
###################################################
plotLogConcTime()


###################################################
### code chunk number 37: plotConcQ
###################################################
plotConcQ()


###################################################
### code chunk number 38: figplotConcQ
###################################################
plotConcQ()


###################################################
### code chunk number 39: plotLogConcQ
###################################################
plotLogConcQ()


###################################################
### code chunk number 40: figplotLogConcQ
###################################################
plotLogConcQ()


###################################################
### code chunk number 41: plotLogFluxQ
###################################################
plotLogFluxQ()


###################################################
### code chunk number 42: figplotLogFluxQ
###################################################
plotLogFluxQ()


###################################################
### code chunk number 43: multiPlotDataOverview
###################################################
multiPlotDataOverview()


###################################################
### code chunk number 44: figmultiPlotDataOverview
###################################################
multiPlotDataOverview()


###################################################
### code chunk number 45: box2
###################################################
  bp <- boxConcMonth()
  mtext(paste(bp$n, sep = ""), at = seq_along(bp$n), 
        line = -1, side = 3, cex=0.75)
  mtext("n = ",side=3,line=-1,adj=.01, cex=0.75)


###################################################
### code chunk number 46: figBox2
###################################################
  bp <- boxConcMonth()
  mtext(paste(bp$n, sep = ""), at = seq_along(bp$n), 
        line = -1, side = 3, cex=0.75)
  mtext("n = ",side=3,line=-1,adj=.01, cex=0.75)


###################################################
### code chunk number 47: flowDuration
###################################################
flowDuration()


###################################################
### code chunk number 48: wrtds2 (eval = FALSE)
###################################################
## modelEstimation()


###################################################
### code chunk number 49: wrtds3 (eval = FALSE)
###################################################
## AnnualResults<-setupYears()


###################################################
### code chunk number 50: wrtds4 (eval = FALSE)
###################################################
## savePath <- "C:/Users/ldecicco/WRTDS_Output"
## saveResults(savePath) 


###################################################
### code chunk number 51: plotWRTDSList (eval = FALSE)
###################################################
## #All plotting functions post-modelEstimation:
## 
## yearStart <- 2008
## yearEnd <- 2010
## 
## #Require Sample + INFO:
## boxResidMonth()
## plotConcTimeDaily(yearStart, yearEnd)
## plotFluxTimeDaily(yearStart, yearEnd)
## plotConcPred()
## plotFluxPred()
## plotLogConcPred()
## plotLogFluxPred(tinyPlot=FALSE)
## plotResidPred()
## plotResidQ()
## plotResidTime()
## 
## #Require annualResults + INFO:
## AnnualResults <- setupYears()
## plotConcHist()
## plotFluxHist()
## 
## # Multi-line plots:
## date1 <- "2000-09-01"
## date2 <- "2005-09-01"
## date3 <- "2009-09-01"
## plotLogConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2, concMin=0.1)
## plotConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2)
## q1 <- 10
## q2 <- 25
## q3 <- 75
## centerDate <- "07-01"
## plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)
## 
## # Multi-plot:
## fluxBiasMulti()
## 
## #Contour plots:
## qBottom<-0.1
## qTop<-100
## clevel<-seq(0,2,0.5)
## maxDiff<-0.8
## plotContours(yearStart,yearEnd,qBottom,qTop, contourLevels = clevel)
## plotDiffContours(year0=2000,yearEnd,qBottom,qTop,maxDiff)


###################################################
### code chunk number 52: boxResidMonth
###################################################
Sample <- exSample
Daily <- exDaily
INFO <- exINFO
AnnualResults <- setupYears()
surfaces <- exsurfaces
qBottom<-0.1
qTop<-100
clevel<-seq(0,2,0.5)
maxDiff<-0.8
yearStart <- 2008
yearEnd <- 2010
date1 <- "2000-09-01"
date2 <- "2005-09-01"
date3 <- "2009-09-01"
q1 <- 10
q2 <- 25
q3 <- 75
centerDate <- "07-01"
boxResidMonth()


###################################################
### code chunk number 53: figboxResidMonth
###################################################
Sample <- exSample
Daily <- exDaily
INFO <- exINFO
AnnualResults <- setupYears()
surfaces <- exsurfaces
qBottom<-0.1
qTop<-100
clevel<-seq(0,2,0.5)
maxDiff<-0.8
yearStart <- 2008
yearEnd <- 2010
date1 <- "2000-09-01"
date2 <- "2005-09-01"
date3 <- "2009-09-01"
q1 <- 10
q2 <- 25
q3 <- 75
centerDate <- "07-01"
boxResidMonth()


###################################################
### code chunk number 54: plotConcTimeDaily
###################################################
plotConcTimeDaily(yearStart,yearEnd)


###################################################
### code chunk number 55: figplotConcTimeDaily
###################################################
plotConcTimeDaily(yearStart,yearEnd)


###################################################
### code chunk number 56: plotFluxTimeDaily
###################################################
plotFluxTimeDaily(yearStart, yearEnd)


###################################################
### code chunk number 57: figplotFluxTimeDaily
###################################################
plotFluxTimeDaily(yearStart, yearEnd)


###################################################
### code chunk number 58: plotConcPred
###################################################
plotConcPred()


###################################################
### code chunk number 59: figplotConcPred
###################################################
plotConcPred()


###################################################
### code chunk number 60: plotFluxPred
###################################################
plotFluxPred()


###################################################
### code chunk number 61: figplotFluxPred
###################################################
plotFluxPred()


###################################################
### code chunk number 62: plotLogConcPred
###################################################
plotLogConcPred()


###################################################
### code chunk number 63: figplotLogConcPred
###################################################
plotLogConcPred()


###################################################
### code chunk number 64: plotLogFluxPred
###################################################
plotLogFluxPred(tinyPlot=FALSE)


###################################################
### code chunk number 65: figplotLogFluxPred
###################################################
plotLogFluxPred(tinyPlot=FALSE)


###################################################
### code chunk number 66: plotResidPred
###################################################
plotResidPred()


###################################################
### code chunk number 67: figplotResidPred
###################################################
plotResidPred()


###################################################
### code chunk number 68: plotResidQ
###################################################
plotResidQ()


###################################################
### code chunk number 69: figplotResidQ
###################################################
plotResidQ()


###################################################
### code chunk number 70: plotResidTime
###################################################
plotResidTime()


###################################################
### code chunk number 71: figplotResidTime
###################################################
plotResidTime()


###################################################
### code chunk number 72: plotConcHist
###################################################
plotConcHist()


###################################################
### code chunk number 73: figplotConcHist
###################################################
plotConcHist()


###################################################
### code chunk number 74: plotFluxHist
###################################################
plotFluxHist()


###################################################
### code chunk number 75: figplotFluxHist
###################################################
plotFluxHist()


###################################################
### code chunk number 76: plotConcQSmooth
###################################################
plotConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2)


###################################################
### code chunk number 77: figplotConcQSmooth
###################################################
plotConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2)


###################################################
### code chunk number 78: plotLogConcQSmooth
###################################################
plotLogConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2, concMin=0.1)


###################################################
### code chunk number 79: figplotLogConcQSmooth
###################################################
plotLogConcQSmooth(date1, date2, date3, qBottom, qTop, concMax=2, concMin=0.1)


###################################################
### code chunk number 80: plotConcTimeSmooth
###################################################
plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)


###################################################
### code chunk number 81: figplotConcTimeSmooth
###################################################
plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)


###################################################
### code chunk number 82: fluxBiasMulti
###################################################
fluxBiasMulti()


###################################################
### code chunk number 83: figfluxBiasMulti
###################################################
fluxBiasMulti()


###################################################
### code chunk number 84: plotContours
###################################################
plotContours(yearStart,yearEnd,qBottom,qTop)


###################################################
### code chunk number 85: figplotContours
###################################################
plotContours(yearStart,yearEnd,qBottom,qTop)


###################################################
### code chunk number 86: plotDiffContours
###################################################
plotDiffContours(year0=2000,yearEnd,qBottom,qTop,maxDiff)


###################################################
### code chunk number 87: figplotDiffContours
###################################################
plotDiffContours(year0=2000,yearEnd,qBottom,qTop,maxDiff)


###################################################
### code chunk number 88: tableResults1
###################################################
tableResults()


###################################################
### code chunk number 89: tableResults1 (eval = FALSE)
###################################################
## tableOut <- tableResults(returnDataFrame = TRUE)
## 
## data.table <- xtable(tableOut, 
##     caption="Table created from tableResults function",
##     label="table:tableResults")
## print(data.table, caption.placement="top",
##       include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 90: tableChange1
###################################################
tableChange()


###################################################
### code chunk number 91: tableChange2 (eval = FALSE)
###################################################
## changeOutput <- tableChangeSingle(fluxUnit=3, flux=TRUE,
##         yearPoints=c(2002,2004,2006), returnDataFrame = TRUE)
## 
## data.table <- xtable(changeOutput, 
##         caption="Table created from tableChangeSingle function",
##         label="table:tableChangeSingle")
## print(data.table, caption.placement="top",
##       include.rownames=FALSE,table.placement="!ht")


###################################################
### code chunk number 92: helpFunc (eval = FALSE)
###################################################
## ?getJulian


###################################################
### code chunk number 93: rawFunc
###################################################
getJulian


###################################################
### code chunk number 94: installFromCran (eval = FALSE)
###################################################
## install.packages(c("zoo","survival","methods","fields","spam"))
## install.packages("dataRetrieval", repos="http://usgs-r.github.com/", 
##                  type="source")
## install.packages("EGRET", repos="http://usgs-r.github.com/", 
##                  type="source")


###################################################
### code chunk number 95: openLibraryTest (eval = FALSE)
###################################################
## library(dataRetrieval)
## library(EGRET)


###################################################
### code chunk number 96: gitInstal (eval = FALSE)
###################################################
## library(devtools)
## install_github("dataRetrieval", "USGS-R")
## install_github("EGRET", "USGS-R")


###################################################
### code chunk number 97: openLibrary (eval = FALSE)
###################################################
## library(dataRetrieval)
## library(EGRET)


###################################################
### code chunk number 98: getSiteApp
###################################################
siteNumber <- '01491000'
ChoptankAvailableData <- getDataAvailability(siteNumber)
ChoptankDailyData <- ChoptankAvailableData["dv" == ChoptankAvailableData$service,]
ChoptankDailyData <- ChoptankDailyData["00003" == ChoptankDailyData$statCd,]
pCodeINFO <- getMultipleParameterNames(ChoptankDailyData$parameter_cd, interactive=FALSE)
ChoptankDailyData <- merge(ChoptankDailyData,pCodeINFO,by="parameter_cd")

tableData <- with(ChoptankDailyData, 
      data.frame(
      shortName=srsname, 
      Start=startDate, 
      End=endDate, 
      Count=count,
      Units=parameter_units)
      )


###################################################
### code chunk number 99: saveData (eval = FALSE)
###################################################
## write.table(tableData, file="tableData.tsv",sep="\t",
##             row.names = FALSE,quote=FALSE)


