
## @knitr openLibrary, echo=FALSE
library(xtable)
options(continue=" ")
options(width=60)
library(knitr)



## @knitr include=TRUE ,echo=FALSE,eval=TRUE
opts_chunk$set(highlight=TRUE, tidy=TRUE, keep.space=TRUE, keep.blank.space=FALSE, keep.comment=TRUE, concordance=TRUE,tidy=FALSE)

knit_hooks$set(inline = function(x) {
   if (is.numeric(x)) round(x, 3)})
knit_hooks$set(crop = hook_pdfcrop)


## @knitr workflow, echo=TRUE,eval=FALSE
## library(dataRetrieval)
## library(EGRET)
## 
## ############################
## # Gather discharge data:
## siteID <- "01491000" #Choptank River at Greensboro, MD
## startDate <- "" #Gets earliest date
## endDate <- "2011-09-30"
## Daily <- getDVData(siteID,"00060",startDate,endDate)
## 
## # Gather sample data:
## parameter_cd<-"00631" #5 digit USGS code
## Sample <- getSampleData(siteID,parameter_cd,startDate,endDate)
## 
## # Gather site and parameter information:
## INFO<- getMetaData(siteID,parameter_cd,interactive=FALSE)
## INFO$shortName <- "Choptank River"
## INFO <- setPA()
## 
## # Merge discharge with sample data:
## Sample <- mergeReport()
## ############################
## 
## ############################
## # Check flow history data:
## annualSeries <- makeAnnualSeries()
## plotFlowSingle(istat=7,qUnit="thousandCfs")
## plotSDLogQ()
## plotQTimeDaily(1990,2010,qLower=1,qUnit=3)
## plotFour(qUnit=3)
## plotFourStats(qUnit=3)
## ############################
## 
## ############################
## # Check sample data:
## boxConcMonth()
## boxQTwice()
## plotLogConcTime()
## plotConcTime()
## plotConcQ()
## plotLogConcQ()
## plotLogFluxQ()
## multiPlotDataOverview()
## ############################
## 
## ############################
## # Run WRTDS model:
## modelEstimation()
## ############################
## 
## ############################
## #Check model results:
## yearStart <- 2000
## yearEnd <- 2010
## 
## #Require Sample + INFO:
## plotConcTimeDaily(yearStart, yearEnd)
## plotFluxTimeDaily(yearStart, yearEnd)
## plotConcPred()
## plotFluxPred()
## plotLogConcPred()
## plotLogFluxPred()
## plotResidPred()
## plotResidQ()
## plotResidTime()
## boxResidMonth()
## boxConcThree()
## 
## #Require annualResults + INFO:
## plotConcHist()
## plotFluxHist()
## 
## # Multi-line plots:
## date1 <- "2000-09-01"
## date2 <- "2005-09-01"
## date3 <- "2009-09-01"
## qBottom<-100
## qTop<-5000
## plotLogConcQSmooth(date1, date2, date3, qBottom, qTop,
##                    concMax=2, concMin=0.1,qUnit=1)
## plotConcQSmooth(date1, date2, date3, qBottom, qTop,
##                    concMax=2,qUnit=1)
## q1 <- 10
## q2 <- 25
## q3 <- 75
## centerDate <- "07-01"
## plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)
## 
## # Multi-plot:
## fluxBiasMulti()
## fluxBiasMultiAlt()
## fluxBiasEight()
## 
## #Contour plots:
## clevel<-seq(0,2,0.5)
## maxDiff<-0.8
## plotContours(yearStart,yearEnd,qBottom,qTop,
##              contourLevels = clevel,qUnit=1)
## plotDiffContours(year0=2000,yearEnd,
##                  qBottom,qTop,maxDiff,qUnit=1)
## 


## @knitr openlibraries, echo=TRUE,eval=TRUE
library(dataRetrieval)
library(EGRET)


## @knitr cheatSheets,echo=TRUE,eval=TRUE
printqUnitCheatSheet()


## @knitr cheatSheets2,echo=TRUE,eval=TRUE
printFluxUnitCheatSheet()


## @knitr vignette1, eval=FALSE, echo=TRUE
## vignette("dataRetrieval")


## @knitr flowHistory,echo=TRUE,eval=TRUE
siteID <- "14105700"  
startDate <- ""
endDate <- ""

Daily <- getDVData(siteID,"00060",startDate,endDate)
INFO <- getMetaData(siteID,"",interactive=FALSE)
INFO$shortName <- "Columbia River"


## @knitr newChunckWinter, echo=TRUE,eval=FALSE
## INFO <- setPA(paStart=12,paLong=3)


## @knitr newChunck, echo=TRUE,eval=TRUE
INFO <- setPA()


## @knitr newChunckAS, echo=TRUE,eval=TRUE
annualSeries <- makeAnnualSeries()


## @knitr plotFlow, echo=TRUE, eval=FALSE
## plotFlowSingle(istat=5,qUnit="thousandCfs")
## plotSDLogQ()
## plotFour(qUnit=3)
## plotFourStats(qUnit=3)


## @knitr plotSingleandSD, echo=FALSE, fig.cap="Discharge statistics",fig.subcap=c("plotFlowSingle(istat=5,qUnit='thousandCfs')","plotSDLogQ()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotFlowSingle(istat=5,qUnit="thousandCfs")
plotSDLogQ()


## @knitr plotFour, echo=FALSE, fig.cap="plotFour(qUnit=3)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
plotFour(qUnit=3)


## @knitr plotFourStats,echo=FALSE, fig.cap="plotFourStats(qUnit=3)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
plotFourStats(qUnit=3)


## @knitr Merced, echo=TRUE,eval=TRUE,fig.cap="Merced River Winter Trend",fig.subcap=c("Water Year", "Dec-Feb"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
sta<-"11264500"
Daily <-getDVData(sta,"00060",StartDate="",EndDate="")
INFO <- getMetaData(sta,"",interactive=FALSE)
INFO$shortName <- "Merced River, CA"
INFO <- setPA(paStart=6, paLong=3)
annualSeries <- makeAnnualSeries()
plotFlowSingle(istat=5)

INFO<-setPA(paStart=12,paLong=3)
annualSeries<-makeAnnualSeries()
plotFlowSingle(istat=5)



## @knitr Mississippi, echo=TRUE,eval=TRUE,fig.cap="Mississippi River at Keokuk Iowa",fig.subcap=c("Water Year", "Dec-Feb"),out.width='1\\linewidth',out.height='1\\linewidth',fig.show='hold'
sta<-"05474500"
Daily <-getDVData(sta,"00060",StartDate="",EndDate="")
INFO <- getMetaData(sta,"",interactive=FALSE)
INFO$shortName <- "Mississippi River at Keokuk Iowa"
INFO <- setPA()

plotQTimeDaily(startYear=1870,endYear=2020,qUnit=3,qLower=300)



## @knitr printSeries, eval=FALSE,echo=TRUE
## printSeries(istat=3, qUnit=3)


## @knitr eval=TRUE,echo=TRUE
annualSeries <- makeAnnualSeries()
tableFlowChange(istat=3, qUnit=3,yearPoints=c(1890,1950,2010))


## @knitr wrtds1,eval=FALSE,echo=TRUE
## siteID <- "01491000" #Choptank River at Greensboro, MD
## startDate <- "1979-10-01"
## endDate <- "2011-09-30"
## param<-"00631"
## Daily <- getDVData(siteID,"00060",startDate,endDate)
## INFO<- getMetaData(siteID,param,interactive=FALSE)
## INFO$shortName <- "Choptank River"
## 
## Sample <- getSampleData(siteID,param,startDate,endDate)
## Sample <- mergeReport()


## @knitr wrtds2,eval=TRUE,echo=FALSE
siteID <- "01491000" #Choptank River at Greensboro, MD
startDate <- "1979-10-01"
endDate <- "2011-09-30"
param<-"00631"
Daily <- ChopDaily
Sample <- ChopSample
INFO <- ChopINFO
annualSeries <- makeAnnualSeries()


## @knitr plotList, echo=TRUE,eval=FALSE
## boxConcMonth()
## boxQTwice(qUnit=1)
## plotConcTime()
## plotLogConcTime()
## plotConcQ(qUnit=1)
## plotLogConcQ(qUnit=1)
## plotLogFluxQ(qUnit=1)
## multiPlotDataOverview(qUnit=1)


## @knitr plotBoxes, echo=FALSE, fig.cap="Concentration box plots",fig.subcap=c("boxConcMonth()","boxQTwice(qUnit=1)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
boxConcMonth()
boxQTwice(qUnit=1)


## @knitr plotConcTime,echo=FALSE, fig.cap="Concentration vs time",fig.subcap=c("plotConcTime()","plotLogConcTime()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcTime()
plotLogConcTime()


## @knitr plotConcQ, echo=FALSE, fig.cap="Concentration vs discharge",fig.subcap=c("plotConcQ(qUnit=1)","plotLogConcQ(qUnit=1)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcQ(qUnit=1)
plotLogConcQ(qUnit=1)


## @knitr plotLogConcQ, echo=FALSE, fig.cap="plotLogFluxQ(qUnit=1)",out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotLogFluxQ(qUnit=1)


## @knitr multiPlotDataOverview, echo=FALSE, fig.cap="multiPlotDataOverview(qUnit=1)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
multiPlotDataOverview(qUnit=1)


## @knitr plotLogConcQComparison,echo=TRUE,eval=TRUE,fig.cap="Modified plotLogConcQ", fig.subcap=c("Default","Modified"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotLogConcQ()
par(mar=c(8,8,8,8))
plotLogConcQ(customPar=TRUE,col="blue",cex=1.1,
             cex.axis=1.4,cex.main=1.5,cex.lab=1.2)
legend(5,.1,"Choptank Nitrogen", pch=20, col="blue")
grid()


## @knitr plot-fascinating2,echo=TRUE,eval=TRUE,fig.cap="Modified box plot",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
# Adding text to a boxplot:
bp <- boxConcMonth()
mtext(paste(bp$n, sep = ""), at = seq_along(bp$n), 
      line = -1, side = 3, cex=0.75)
mtext("n = ",side=3,line=-1,adj=.01, cex=0.75)


## @knitr flowDuration, eval=TRUE, echo=TRUE
flowDuration()


## @knitr wrtds3, eval=FALSE, echo=TRUE
## modelEstimation()


## @knitr wrtds4, eval=FALSE, echo=TRUE
## AnnualResults<-setupYears(paStart=12,paLong=3)


## @knitr wrtds5, eval=FALSE, echo=TRUE
## savePath <- "C:/Users/ldecicco/WRTDS_Output"
## saveResults(savePath)


## @knitr wrtds6, eval=FALSE, echo=TRUE
## save(Daily, file="Daily.RData")
## save(Sample, file="Sample.RData")
## save(INFO, file="INFO.RData")
## save(AnnualResults, file="AnnualResults.RData")
## save(surfaces, file="surfaces.RData")


## @knitr wrtds7, eval=FALSE, echo=TRUE
## load(Daily, file="Daily.RData")
## load(Sample, file="Sample.RData")
## load(INFO, file="INFO.RData")
## load(AnnualResults, file="AnnualResults.RData")
## load(surfaces, file="surfaces.RData")


## @knitr plotWRTDSList, echo=TRUE,eval=FALSE
## #Require Sample + INFO:
## plotConcTimeDaily(2008, 2010)
## plotFluxTimeDaily(2008, 2010)
## plotConcPred()
## plotFluxPred()
## plotLogConcPred()
## plotLogFluxPred()
## plotResidPred()
## plotResidQ(qUnit=1)
## plotResidTime()
## boxResidMonth()
## boxConcThree(qUnit=1)
## 
## #Require annualResults + INFO:
## plotConcHist()
## plotFluxHist()
## 
## # Multi-line plots:
## date1 <- "2000-09-01"
## date2 <- "2005-09-01"
## date3 <- "2009-09-01"
## qBottom<-1
## qTop<-5000
## plotLogConcQSmooth(date1, date2, date3, qBottom, qTop,
##                    concMax=2, concMin=0.1,qUnit=1)
## plotConcQSmooth(date1, date2, date3, qBottom, qTop,
##                    concMax=2,qUnit=1)
## q1 <- 10
## q2 <- 25
## q3 <- 75
## centerDate <- "07-01"
## plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, 2010)
## 
## # Multi-plot:
## fluxBiasMulti(qUnit=1)
## fluxBiasMultiAlt(qUnit=1)
## fluxBiasEight(qUnit=1)
## 
## #Contour plots:
## clevel<-seq(0,2,0.5)
## maxDiff<-2
## plotContours(2008,2010,qBottom,qTop,
##              contourLevels = clevel,qUnit=1)
## plotDiffContours(year0=2000,2010,
##                  qBottom,qTop,maxDiff,qUnit=1)


## @knitr plotConcTimeDaily, echo=FALSE, fig.cap="Concentration and flux vs time",fig.subcap=c("plotConcTimeDaily(yearStart=2008, yearEnd=2010)","plotFluxTimeDaily(yearStart=2008, yearEnd=2010)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
Sample <- ChopSample
Daily <- ChopDaily
INFO <- ChopINFO
AnnualResults <- setupYears()
surfaces <- exsurfaces
qBottom<-1
qTop<-5000
clevel<-seq(0,2,0.5)
maxDiff<-2
yearStart <- 2008
yearEnd <- 2010
date1 <- "2000-09-01"
date2 <- "2005-09-01"
date3 <- "2009-09-01"
q1 <- 10
q2 <- 25
q3 <- 75
centerDate <- "07-01"
plotConcTimeDaily(yearStart, yearEnd)
plotFluxTimeDaily(yearStart, yearEnd)


## @knitr plotFluxPred, echo=FALSE, fig.cap="Concentration predictions",fig.subcap=c('plotConcPred()','plotLogConcPred()'),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcPred()
plotLogConcPred()


## @knitr plotLogFluxPred, echo=FALSE, fig.cap="Flux predictions",fig.subcap=c('plotFluxPred()','plotLogFluxPred()'), out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotFluxPred()
plotLogFluxPred()


## @knitr plotResidQ, echo=FALSE, fig.cap="Residuals",fig.subcap=c("plotResidPred()","plotResidQ(qUnit=1)"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotResidPred()
plotResidQ(qUnit=1)


## @knitr boxResidMonth, echo=FALSE, fig.cap="Residuals with respect to time",fig.subcap=c("plotResidTime()","boxResidMonth()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotResidTime()
boxResidMonth()


## @knitr boxConcThree, echo=FALSE, fig.cap="Default boxConcThree()",out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='asis',results='hide'
boxConcThree()


## @knitr plotFluxHist, echo=FALSE, fig.cap="Concentration and flux history",fig.subcap=c("plotConcHist()", "plotFluxHist()"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcHist()
plotFluxHist()


## @knitr plotLogConcQSmooth, echo=FALSE, fig.cap="Concentration vs. discharge",fig.subcap=c("plotConcQSmooth","plotLogConcQSmooth"),out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='hold'
plotConcQSmooth(date1, date2, date3, qBottom, qTop, 
                   concMax=1.5,qUnit=1)
plotLogConcQSmooth(date1, date2, date3, qBottom, qTop,
                   concMax=1.5, concMin=0.1,qUnit=1)


## @knitr plotConcTimeSmooth, echo=FALSE, fig.cap="plotConcTimeSmooth",out.width='.5\\linewidth',out.height='.5\\linewidth',fig.show='asis',results='hide'
plotConcTimeSmooth(q1, q2, q3, centerDate, 2000, yearEnd)


## @knitr fluxBiasMulti, echo=FALSE, fig.cap="fluxBiasMulti(qUnit=1)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
fluxBiasMulti(qUnit=1)


## @knitr fluxBiasMultiAlt, echo=FALSE, fig.cap="fluxBiasMultiAlt(qUnit=1)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
fluxBiasMultiAlt(qUnit=1)


## @knitr fluxBiasEight, echo=FALSE, fig.cap="fluxBiasEight(qUnit=1)",fig.show='asis',fig.width=8, fig.height=10
fluxBiasEight(qUnit=1)


## @knitr plotContours, echo=FALSE, fig.cap="plotContours(2008,2010,1,5000,clevel,qUnit=1)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
surfaces <- exsurfaces
Daily <- ChopDaily
INFO <- ChopINFO
plotContours(yearStart,yearEnd,1,5000, 
             contourLevels = clevel,qUnit=1)


## @knitr plotDiffContours, echo=FALSE, fig.cap="plotDiffContours(year0=2000,yearEnd=2010,qBottom=1,qTop=5000,maxDiff=2)",fig.show='asis',out.width='1\\linewidth',out.height='1\\linewidth'
plotDiffContours(year0=2000,yearEnd,
                 1,5000,maxDiff,qUnit=1)


## @knitr setcontours, echo=TRUE, eval=FALSE
## contourLevels = seq(0,5,0.2)


## @knitr tableResults1, echo=TRUE, eval=TRUE
tableResults()


## @knitr tableResults2, eval=FALSE,echo=TRUE,results='hide'
## library(xtable)
## tableOut <- tableResults(returnDataFrame = TRUE)
## tableOut <- head(tableOut)
## xtable(tableOut,
##     caption="Table created from tableResults function",
##     label="table:tableResults")


## @knitr tableChange1, eval=TRUE, echo=TRUE
tableChange()


## @knitr tableChange2, echo=TRUE, eval=TRUE,results='hide'
library(xtable)
changeOutput <- tableChangeSingle(fluxUnit=5, 
        yearPoints=c(2002,2004,2006), 
        returnDataFrame = TRUE,
        flux=TRUE)

xtable(changeOutput, 
        caption="Table created from tableChangeSingle function",
        label="table:tableChangeSingle")



## @knitr helpFunc,eval = FALSE
## ?getJulian


## @knitr rawFunc,eval = FALSE
## getJulian


## @knitr installFromCran,eval = FALSE
## install.packages(c("zoo","survival","methods","fields","spam"))
## install.packages("dataRetrieval",
##                  repos="http://usgs-r.github.com/",
##                  type="source")
## install.packages("EGRET",
##                  repos="http://usgs-r.github.com/",
##                  type="source")


## @knitr openLibraryTest, eval=FALSE
## library(dataRetrieval)
## library(EGRET)


## @knitr label=getSiteApp, echo=TRUE
siteNumber <- '01491000'
ChopAvail <- getDataAvailability(siteNumber)
ChopDaily <- ChopAvail["dv" == ChopAvail$service,]
ChopDaily <- ChopDaily["00003" == ChopDaily$statCd,]
pCodeINFO <- getMultipleParameterNames(ChopDaily$parameter_cd,                                 interactive=FALSE)
ChopDaily <- merge(ChopDaily,pCodeINFO,by="parameter_cd")

tableData <- with(ChopDaily, data.frame(shortName=srsname, 
              Start=startDate, End=endDate, Count=count, 
              Units=parameter_units))


## @knitr label=saveData, echo=TRUE, eval=FALSE
## write.table(tableData, file="tableData.tsv",sep="\t",
##             row.names = FALSE,quote=FALSE)


## @knitr label=savePlots, echo=TRUE, eval=FALSE
## jpeg("plotFlowSingle.jpg")
## plotFlowSingle(1)
## dev.off()
## 
## png("plotFlowSingle.png")
## plotFlowSingle(1)
## dev.off()
## 
## pdf("plotFlowSingle.pdf")
## plotFlowSingle(1)
## dev.off()
## 
## postscript("plotFlowSingle.ps")
## plotFlowSingle(1)
## dev.off()
## 


## @knitr label=savePlots2, echo=TRUE, eval=FALSE
## postscript("fluxBiasEight.ps", height=10,width=8)
## fluxBiasEight()
## dev.off()
## 
## pdf("fluxBiasEight.pdf", height=10,width=8)
## fluxBiasEight()
## dev.off()
## 


