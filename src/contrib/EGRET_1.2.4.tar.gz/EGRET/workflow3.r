# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("EnDDaT/",reset = TRUE)
document("EnDDaT")

build("EnDDaT")
install("EnDDaT")
check("EnDDaT")

install.packages("D:/LADData/RCode/EnDDaT_1.0.1.tar.gz", repos=NULL,type="source")




install.packages("//igsarmewfsapa/projects/QW Monitoring Team/GLRI beaches/Modeling/EnDDaT modeling results/R Codes/EnDDaT_1.0.0.tar.gz", repos=NULL,type="source")

library("EnDDaT")
fileName <- "ULPParams4.csv"
filePath <- "//igsarmewfsapa/projects/QW Monitoring Team/GLRI beaches/Modeling/Model development 2012/ULP"

# fileName <- "ULPParams4.csv"
# filePath <- "//igsarmewfsapa/projects/QW Monitoring Team/GLRI beaches/Modeling/Model development 2012/ULP"
setwd(filePath)
# filePath <- getwd()
totalParams <- getParamsFromFile(filePath, fileName)

#General beach info:
tzone <- '-6_CST'
lake <- 'michigan'
gap <- 6

# It might be OK to grab entire record for NWIS...but definitely not GLCFS data:
ULP2007ID <- "f04ab043-4136-4637-8e74-0b9a0e7644af"
ULP2008ID <- "36347bd7-1388-4b9a-8860-059151474ba4"
ULP2009ID <- "17a6260e-d889-4cde-9543-3b5c791531e6"
ULP2010ID <- "d2c765d9-19d6-4ece-b3a1-378527cc5c2b"
ULP2011ID <- "a7975eef-f835-4505-a631-ba48a113dd2f"
ULP2012ID <- "a1e30115-e6c9-4945-a738-f06466bfc009"

#Optional:
beachName <- 'Upper Lake Park'
#other options:
# beginPosition <- '2006-10-02'
# endPosition <- '2006-10-05'
# beachLat <- ''
# beachLon <- ''

# *Should* increase loading time
setInternet2(use=NA)
setInternet2(use=FALSE)
setInternet2(use=NA)
options(timeout=120)

#2012
baseReturn <- generateBaseUrl(beachName = beachName, tzone=tzone,lake=lake,filter = ULP2012ID,gap=gap)
#Quick test:
totalParams <- getParamsFromFile(filePath, fileName)
subParams <- totalParams[c(91,96,161,166),]
GLCFSData20122 <- getGLCFSData(subParams,baseReturn)

#Slow!:
NWISData2012 <- getNWISData(totalParams,baseReturn)
GLCFSData2012 <- getGLCFSData(totalParams,baseReturn)
EnDDaTData2012 <- mergeENDDAT(NWISData2012 , NWISData2012)


#2011
baseReturn2011 <- generateBaseUrl(beachName = beachName, tzone=tzone,lake=lake,filter = ULP2011ID,gap=gap)
#Slow!:
NWISData2011 <- getNWISData(totalParams,baseReturn2011)
GLCFSData2011 <- getGLCFSData(totalParams,baseReturn2011)
EnDDaTData2011 <- mergeENDDAT(NWISData2011, GLCFSData2011)
EnDDaTData <- mergeENDDAT(EnDDaTData2012, EnDDaTData2011)

#2010
baseReturn2010 <- generateBaseUrl(beachName = beachName, tzone=tzone,lake=lake,filter = ULP2010ID,gap=gap)
#Slow!:
NWISData2010 <- getNWISData(totalParams,baseReturn2010)
GLCFSData2010 <- getGLCFSData(totalParams,baseReturn2010)
EnDDaTData2010 <- mergeENDDAT(NWISData2010, GLCFSData2010)
EnDDaTData <- mergeENDDAT(EnDDaTData, EnDDaTData2010)

write.csv(EnDDaTData,file="ULP2010to2012_Laura.csv",row.names=FALSE)

test <- unique(beachTribKey[,c("BEACH_ID","BEACH_DESC")])

beaches <- read.csv("D:/LADData/RCode/EnDDaT/BEACH_REF.csv")
test2 <- beaches[,c("BEACH_ID", "BEACH_NAME", "LAKE_NAME")]
test2$lake <- gsub("Lake Michigan", "michigan",test2$LAKE_NAME)
test2$lake <- ifelse("michigan" == test2$lake, test2$lake, gsub("Lake Ontario", "ontario",test2$LAKE_NAME))
test2$lake <- ifelse(("michigan" == test2$lake | "ontario" == test2$lake), test2$lake, gsub("Lake Erie", "erie",test2$LAKE_NAME))
test2$lake <- ifelse(("michigan" == test2$lake | "ontario" == test2$lake | "erie" == test2$lake), test2$lake, gsub("Lake Huron", "huron",test2$LAKE_NAME))
test2$lake <- ifelse(("michigan" == test2$lake | "ontario" == test2$lake | "erie" == test2$lake | "huron" == test2$lake), test2$lake, gsub("Lake Superior", "superior",test2$LAKE_NAME))






