# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("EGRET/",reset = TRUE)
setwd("D:/LADData/RCode/EGRET")
document()
check()  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
setwd("D:/LADData/RCode/")
build("EGRET")
install("EGRET")

# library(devtools)
# install_github("dataRetrieval", "USGS-R")
# install_github("EGRET", "USGS-R")
install.packages("EGRET", repos="http://usgs-r.github.com/", type="source")
install.packages("dataRetrieval", repos="http://usgs-r.github.com/", type="source")

# General workflow:
library(dataRetrieval)
library(EGRET)

sta<-"01491000"
param<-"00631"
StartDate<-"1979-09-01"
EndDate<-"2011-09-30"
Sample<-getSampleData(sta,param,StartDate,EndDate)
summary(Sample)
length(Sample$Date)
Sample<-removeDuplicates(Sample)
length(Sample$Date)
Daily<-getDVData(sta,"00060",StartDate,EndDate)
summary(Daily)
Sample<-mergeReport()
INFO<-getMetaData(sta,param)

modelEstimation()

AnnualResults<-setupYears()


v1 <- vignette("dataRetrieval")
# To see just the R code:
edit(v1)
# To see the generated pdf:
v1

v2 <- vignette("EGRET")
# To see just the R code:
edit(v2)
# To see the generated pdf:
v2
