install.packages(c("dataRetrieval","EGRET"), 
                 repos=c("http://usgs-r.github.com","http://cran.us.r-project.org"),
                 dependencies=TRUE,
                 type="both")

library(dataRetrieval)
library(EGRET)

Daily <- ChopDaily
Sample <- ChopSample
INFO <- ChopINFO

savePDF <- FALSE
if (savePDF) pdf(file="Combo_test.pdf")

saveEPS <- FALSE
if (savePDF) {
  setEPS()
  postscript(file="Combo_test.eps")
  
}

# Just an example of 31 sites
# Mess around with the layout Vector to see how it works

A <- 1:35
layoutVector <- rep(c(0,rep(1,5)),time=7)
layoutVector[layoutVector==1] <- A
layoutVector[18] <- 0
layoutVector[36] <- 0
layoutVector[layoutVector > 14] <- layoutVector[layoutVector > 14]-1
layoutVector[layoutVector > 29] <- layoutVector[layoutVector > 29]-1
layoutVector[41] <- 0
layoutVector[42] <- 32
layoutVector[18] <- 33
layoutVector <- c(layoutVector,rep(0,6))
layout(matrix(layoutVector, 8, 6, byrow = TRUE),
       widths = c(0.5,rep(1,5)), heights=c(rep(1,7),0.5))
# Uncomment this next line to see the layout, but comment it back when running the script:
# layout.show(33)


nSites <- 32

par(mar=c(0.1,0.1,0.1,0.1), mgp=c(1,0.5,0))

for (i in 1:nSites){
  
  # Here you'd have to open up your individual Daily,Sample,INFO dataframes
  
  siteID <- INFO$site.no
  shortName <- INFO$shortName
  
  plotConcHist(printTitle=FALSE,
               col.pred="black",
               customPar=TRUE,
               removeFirstX = (i %in% c(28,30:31)), removeLastX = (i %in% c(28:30)),
               removeFirstY = FALSE, removeLastY = TRUE,
               showXAxis=(i %in% c(28:32)),
               showYLabels = FALSE,
               showYAxis=(i %in% c(1,6,11,15,20,25,29)))
  
}

if (savePDF | saveEPS) dev.off()
