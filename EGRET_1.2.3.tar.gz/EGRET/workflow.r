# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("EGRETGitorious/",reset = TRUE)
setwd("D:/LADData/RCode/EGRETGitorious")
document()
check()  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
setwd("D:/LADData/RCode/")
build("EGRETGitorious")
install("EGRETGitorious")