# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("EGRET/",reset = TRUE)
setwd("D:/LADData/RCode/EGRET")
document()
check()  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
setwd("D:/LADData/RCode/")
build("EGRET")
install("EGRET")